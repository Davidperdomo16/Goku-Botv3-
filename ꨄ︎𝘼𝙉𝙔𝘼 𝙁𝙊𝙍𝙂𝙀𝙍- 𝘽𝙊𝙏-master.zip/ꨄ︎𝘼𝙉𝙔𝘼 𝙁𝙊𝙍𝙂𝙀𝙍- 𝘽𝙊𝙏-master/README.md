# **🔥 𝗧𝗵𝗲 𝗦𝗵𝗮𝗱𝗼𝘄 𝗕𝗿𝗼𝗸𝗲𝗿𝘀 - 𝗕𝗼𝘁 🔥**

## El Bot ya no recibira mas actualizaciones

### `NECESITAS AYUDA?, CONTACTAME`
<a href="http://wa.me/5219992095479" target="blank"><img src="https://img.shields.io/badge/BRUNO_SOBRINO-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>
> NO BOT
### `GRUPOS OFICIALES DEL BOT`
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/JlomZPEgo3bLmzjGUYPfyJ)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_2-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/DbXBmsydWBE1ZN3EoY0hRs)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_3-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/BW0P22xx7EGBTdH5IM851F)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_4-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/CjexkGVr37J6GuSdDVAHzC)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_5-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/H7NUXdrGlFg20ae3bqgwlb)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_6-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/GvrLSUSzVuT9P17CKfdxDa)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_7-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/EpzuymKm6lG08k6J2Dwx7F)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_8-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/IW12dLVoyWGHreGpX7rQIw)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_9-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/Ef89aIuOLeD3Fa2sYmKwp7)
[![Grupo de WhatsApp](https://img.shields.io/badge/GRUPO_OFICIAL_10-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/C2WYb1hiiijCI13QSUZLM9)
### `AJUSTES`
- CAMBIAR NÚMERO DE PROPIETARIO [Aqui](https://github.com/BrunoSobrino/ShadowBotV3.2/blob/master/config.js)

### `Video tutorial para instalar el Bot`
<a href="https://www.youtube.com/watch?v=dP8-aaHinBE&t=55s"><img height="30" src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white"></a>&nbsp;&nbsp;

### `INSTALACION TERMUX`
```bash
> termux-setup-storage
> pkg update && pkg upgrade -y -y
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/BrunoSobrino/ShadowBotV3.2
> cd ShadowBotV3.2
> npm install
> npm install -g npm@8.7.0
> npm update
> npm start
```

### `NOTAS`
```bash
> Para activar algunos comandos como 
el #añadir y #sacar el propietario del 
Bot debera usar el comando #enable restrict 
desde el numero que haya puesto en el archivo 
config.js

> Para obtener nuevamente el codigo QR, escribe en el termux:
> rm -rf session.data.json
> npm start 

> Si el termux se cierra para volver activar escribe:
> cd ShadowBotV3.2
> npm start 

> Cada vez que realices una modificacion en el
repositorio del Bot (tu GitHub), puedes usar 
el comando #actualizar para que se actualicen los datos

> Aconsejable maximo 30 grupos, despues 
de esa cantidad el Bot empieza a ir 
excesivamente lento (depende del WhatsApp igual)
```
### `WHATSAPP "BETA" (MULTI-DEVICE)`
> #### *⚠️ ShadowBotV3.2 no es, ni sera compatible con la versión "beta" de WhatsApp (Multi-Dispositivo - Multi-Device), por lo que se sugiere usar los siguientes WhatsApps*
> ##### Agradecimientos a GataNina-Li por la recopilacion de los WhatsApps
* [Opción 1 - WhatsApp Recomendado](https://www.mediafire.com/file/gers3gbbubpshji/%C3%8A%C2%99%C3%A1%C2%B4%C2%9Cs%C3%8D%C2%A8%C3%89%C2%AA%C3%8D%C2%A7%C3%89%C2%B4%C3%A1%C2%B7%C2%A8%C3%A1%C2%B4%C2%87%C3%8D%C2%A3s%C3%A1%C2%B7%C2%A1s%C3%8D%C2%A6+%C3%A2%C2%A9%C2%945_Secundario.apk/file).
* [Opción 2 - WhatsApp Recomendado](https://www.mediafire.com/file/444tuerbs99y1d2/%25E2%2598%25A3%25EF%25B8%258F%25E2%259F%25BF%25CD%25A1%25CD%259C%25E2%259C%25AA%25F0%259D%2590%258B%25CD%25A5%25F0%259D%2590%259E%25F0%259D%2590%259A%25E1%25B7%25A7%25F0%259D%2590%259D%25E2%25B7%25A8%25F0%259D%2590%259E%25F0%259D%2590%25AB%25F0%2596%25A3%2594%25F0%259D%2590%2582%25F0%259D%2590%25A8%25E1%25B7%2597%25F0%259D%2590%25A6%25E1%25B7%25A2%25F0%259D%2590%259A%25CD%25A5%25F0%259D%2590%25A7%25E1%25B7%25A4%25F0%259D%2590%259D%25E1%25B7%25A4%25F0%259D%2590%25A8%25E2%2598%2598%25EF%25B8%258E.apk/file).
* [Opción 3 - WhatsApp Recomendado](https://www.mediafire.com/file/drcy3rn45buoyr4/%25E2%2598%25A3%25EF%25B8%258F%25F0%2593%2580%25AC%25F0%259D%2597%25A7%25F0%259D%2597%25B6%25F0%259D%2597%25B8%25E2%259C%2587%25F0%259D%2597%25A7%25F0%259D%2597%25BC%25F0%259D%2597%25B8%25F0%2593%2580%25AC.apk/file).
* [Opción 4 - WhatsApp Recomendado](https://www.mediafire.com/file/pxfksca3yatav5f/%25E0%25A6%2594%25E0%25A7%25A3%25CD%25A1%25CD%259C%25E2%258D%25A3%25E2%2582%25AE%25C9%2584%25C9%258C%25C9%2583%25C3%2598%25E0%25AF%2580%25CD%259C%25E2%2582%25A6%25C6%2597%25E2%2582%25AE%25C9%258C%25C3%2598%25E2%259E%25A3%25E2%259C%25AA_%25E2%25A9%2594-7.apk/file).

## `EDITOR Y PORPIETARIO DEL BOT` 
[![BrunoSobrino](https://avatars.githubusercontent.com/u/90165013?s=400&u=946f5c00c527c7e6fa2ef5148c6ad56270bb600e&v=4size=100)](https://avatars.githubusercontent.com/u/90165013?s=400&u=cdf7fd989e2a787c9f400545147865615c336002&v=4) 
```bash
`The Shadow Brokers - Bot ___ By Bruno Sobrino` 
```
