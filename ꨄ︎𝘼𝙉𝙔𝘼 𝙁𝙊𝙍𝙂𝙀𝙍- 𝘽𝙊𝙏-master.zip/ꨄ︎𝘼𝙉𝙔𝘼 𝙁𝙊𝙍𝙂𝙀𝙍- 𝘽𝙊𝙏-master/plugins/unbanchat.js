let handler = async (m, { conn }) => {
  if (!(m.chat in global.DATABASE._data.chats)) return m.reply(`𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝙉𝙊 𝙀𝙎𝙏𝘼 𝙍𝙀𝙂𝙄𝙎𝙏𝙍𝘼𝘿𝙊 𝙀𝙉 𝙇𝘼 𝘽𝘼𝙎𝙀 𝘿𝙀 𝘿𝘼𝙏𝙊𝙎')
  let chat = global.DATABASE._data.chats[m.chat]
  if (!chat.isBanned) return m.reply('𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝙉𝙊 𝙀𝙎𝙏𝘼 𝙋𝙍𝙊𝙃𝙄𝘽𝙄𝘿𝙊')
  chat.isBanned = false
  m.reply('✅ 𝘾𝙃𝘼𝙏 𝘽𝘼𝙉𝙀𝘼𝘿𝙊 𝙀𝙓𝙄𝙏𝙊𝙎𝘼𝙈𝙀𝙉𝙏𝙀')
}
handler.help = ['unbanchat']
handler.tags = ['General']
handler.command = /^unbanchat$/i
handler.owner = false
handler.admin = true

module.exports = handler
