const uploadImage = require('../lib/uploadImage') 
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn, text }) => {
 try {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '𝙁𝙊𝙏𝙊 𝙉𝙊 𝙎𝙊𝙋𝙊𝙍𝙏𝘼𝘿𝘼'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `𝙀𝙇 𝙋𝙀𝙎𝙊 ${mime} 𝘿𝙀 𝙇𝘼 𝙁𝙊𝙏𝙊 𝙉𝙊 𝙀𝙎 𝙎𝙊𝙋𝙊𝙍𝙏𝘼𝘿𝘼`
  let img = await q.download()
  let url = await uploadImage(img)
  let wanted = `https://api.dhamzxploit.my.id/api/canvas/wanted?url=${url}`
  let stiker = await sticker(null, wanted, 'wanted', 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏')
  conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
 } catch (e) {
   m.reply('𝘾𝙊𝙉𝙑𝙀𝙍𝙎𝙄𝙊𝙉 𝙁𝘼𝙇𝙇𝙄𝘿𝘼, 𝙍𝙀𝘾𝙐𝙀𝙍𝘿𝙀 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝙀𝙍 𝘼 𝙐𝙉𝘼 𝙄𝙈𝘼𝙂𝙀𝙉 ')
  }
}
handler.help = ['wanted']
handler.tags = ['General']
handler.command = /^wanted$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
