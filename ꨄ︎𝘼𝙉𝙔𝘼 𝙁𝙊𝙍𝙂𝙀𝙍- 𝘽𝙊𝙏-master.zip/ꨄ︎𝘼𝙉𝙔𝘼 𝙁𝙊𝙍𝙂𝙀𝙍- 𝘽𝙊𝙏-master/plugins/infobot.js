let { MessageType } = require('@adiwajshing/baileys')
let fs = require('fs')
let os = require('os')
let util = require('util')
let { performance } = require('perf_hooks')
let { sizeFormatter } = require('human-readable')
let format = sizeFormatter({
  std: 'JEDEC', // 'SI' (default) | 'IEC' | 'JEDEC'
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})
let handler = async (m, { conn, usedPrefix }) => {
  let _uptime = process.uptime() * 1000
  let uptime = clockString(_uptime) 
  let totalreg = Object.keys(global.DATABASE._data.users).length
  const chats = conn.chats.all()
  const groups = chats.filter(v => v.jid.endsWith('g.us'))
  const groupsIn = groups.filter(v => !v.read_only)
  const used = process.memoryUsage()
  const cpus = os.cpus().map(cpu => {
    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
    return cpu
  })
  const cpu = cpus.reduce((last, cpu, _, { length }) => {
    last.total += cpu.total
    last.speed += cpu.speed / length
    last.times.user += cpu.times.user
    last.times.nice += cpu.times.nice
    last.times.sys += cpu.times.sys
    last.times.idle += cpu.times.idle
    last.times.irq += cpu.times.irq
    return last
  }, {
    speed: 0,
    total: 0,
    times: {
      user: 0,
      nice: 0,
      sys: 0,
      idle: 0,
      irq: 0
    }
  })
  let old = performance.now()
  //await m.reply('_Realizando test_')
  let neww = performance.now()
  let totaljadibot = [...new Set([...global.conns.filter(conn => conn.user && conn.state !== 'close').map(conn => conn.user)])]
  let speed = neww - old
  let info = `
𐏎 ༻☾︎𝙞𝙣𝙛𝙤𝙧𝙢𝙖𝙘𝙞𝙤𝙣 𝙙𝙚𝙡 𝙗𝙤𝙩 ꨄ︎𝘼𝙉𝙔𝘼_𝙁𝙊𝙍𝙂𝙀𝙍☽︎༺
𐏎
𐏎➥[👸] 𝙘𝙧𝙚𝙖𝙙𝙤𝙧𝙖 𝙙𝙚𝙡 𝙗𝙤𝙩: ☾︎𝙨𝙤𝙛𝙞𝙖☽︎
𐏎➥[#👤] 𝙣𝙪𝙢𝙚𝙧𝙤 𝙙𝙚 𝙡𝙖 𝙘𝙧𝙚𝙖𝙙𝙤𝙧𝙖: *wa.me/50495086382*
𐏎➥[🌐] 𝙣𝙖𝙫𝙚𝙜𝙖𝙙𝙤𝙧: *${conn.browserDescription[1]}*
𐏎➥[🎳] 𝙥𝙧𝙚𝙛𝙞𝙟𝙤: *${usedPrefix}*
𐏎➥ [‍⚡] 𝙫𝙚𝙡𝙤𝙘𝙞𝙙𝙖𝙙: *${speed} milisegundos*
𐏎➥ [🔐] 𝙘𝙝𝙖𝙩 𝙥𝙧𝙞𝙫𝙖𝙙𝙤𝙨: *${chats.length - groups.length}*
𐏎➥ [👨‍👩‍👦‍👦] 𝙘𝙝𝙖𝙩 𝙙𝙚 𝙜𝙧𝙪𝙥𝙤𝙨: *${groups.length}* 
𐏎➥ [✅] 𝙘𝙝𝙖𝙩 𝙩𝙤𝙩𝙖𝙡𝙚𝙨: *${chats.length}* 
𐏎➥ [🚀] 𝙩𝙞𝙚𝙢𝙥𝙤 𝙖𝙘𝙩𝙞𝙫𝙤: *${uptime}*
𐏎➥ [👤] 𝙪𝙨𝙪𝙖𝙧𝙞𝙤𝙨: *${totalreg} numeros*
𐏎➥ [🔋] 𝘽𝙖𝙩𝙚𝙧𝙞𝙖: *${conn.battery ? `${conn.battery.value}%* *${conn.battery.live ? '🔌 Cargando...*' : '⚡ Desconectado*'}` : 'Desconocido*'}
𐏎➥[💻] 𝙨𝙞𝙨𝙩𝙚𝙢𝙖 𝙤𝙥𝙚𝙧𝙖𝙩𝙞𝙫𝙤: *${conn.user.phone.device_manufacturer}*
𐏎➥[🧐] 𝙫𝙚𝙧𝙨𝙞𝙤𝙣 𝙙𝙚 𝙬𝙝𝙖𝙩𝙨𝙖𝙥𝙥: *${conn.user.phone.wa_version}*
𐏎➥ [🤖] 𝙗𝙤𝙩𝙨 𝙨𝙚𝙘𝙪𝙣𝙙𝙖𝙧𝙞𝙤𝙨 𝙖𝙘𝙩𝙞𝙫𝙤𝙨: *${totaljadibot.length}*
𐏎
𐏎➥𐏈ꨄ︎𝘼𝙉𝙔𝘼_𝙁𝙊𝙍𝙂𝙀𝙍-𝘽𝙊𝙏ဣ᭄
`.trim() 
conn.sendMessage(m.chat, info, MessageType.text, { quoted: { key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net', fromMe: false }, message: { "imageMessage": { "mimetype": "image/jpeg", "caption": '🖤ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏🖤', "jpegThumbnail": fs.readFileSync(`./Menu2.jpg`)}}}})
}
//handler.help = ['ping', 'speed']
//handler.tags = ['info', 'tools']

handler.command = /^(infobot)$/i

module.exports = handler

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  console.log({ms,h,m,s})
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}
