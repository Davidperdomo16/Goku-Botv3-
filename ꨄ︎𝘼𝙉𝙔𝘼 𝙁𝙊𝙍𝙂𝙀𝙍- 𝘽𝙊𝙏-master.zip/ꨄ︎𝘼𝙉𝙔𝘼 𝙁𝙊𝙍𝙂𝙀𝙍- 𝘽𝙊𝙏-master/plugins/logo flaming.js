let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
response = args.join(' ').split('|')
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤\n𝙚𝙟𝙚𝙢𝙥𝙡𝙤:)\n#𝙛𝙡𝙖𝙢𝙞𝙣𝙜 𝙖𝙣𝙮𝙖'        
let res = `https://api-alc.herokuapp.com/api/photooxy/flaming-fire?texto=${response[0]}&apikey=ConfuMods`
conn.sendFile(m.chat, res, 'error.jpg', `*Logo terminado*`, m, false)}
handler.command = /^(flaming|logoflaming)$/i
module.exports = handler
