let { spawn }  = require('child_process');
let handler  = async (m, { conn }) => {
  if (!process.send) throw 'Dont: node main.js\nDo: node index.js'
  if (global.conn.user.jid == conn.user.jid) {
    await m.reply('𝙍𝙀𝙎𝙏𝘼𝘽𝙇𝙀𝘾𝙄𝙀𝙉𝘿𝙊 𝙀𝙇 𝘽𝙊𝙏...\n\n𝙀𝙎𝙋𝙀𝙍𝙀 1 𝙈𝙄𝙉𝙐𝙏𝙊')
    await global.DATABASE.save()
    process.send('reset')
  } else throw '𝙀𝙎𝙋𝙀𝙍𝙀 𝙐𝙉 𝙈𝙊𝙈𝙀𝙉𝙏𝙊 𝘼𝙉𝙏𝙀𝙎 𝘿𝙀 𝙑𝙊𝙇𝙑𝙀𝙍 𝘼 𝙐𝙎𝘼𝙍 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊'
}
handler.help = ['restart']
handler.tags = ['host']
handler.command = /^restart$/i
handler.rowner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

