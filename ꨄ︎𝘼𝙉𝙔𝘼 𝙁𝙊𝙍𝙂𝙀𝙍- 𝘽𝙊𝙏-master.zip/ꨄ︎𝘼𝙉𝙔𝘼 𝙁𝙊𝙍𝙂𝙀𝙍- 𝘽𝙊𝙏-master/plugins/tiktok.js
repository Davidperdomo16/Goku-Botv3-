let fetch = require('node-fetch')
let handler = async (m, { conn, args, usedPrefix, command, text }) => {
if (!args[0]) throw `𝙁𝙊𝙍𝙈𝘼𝙏𝙊 𝘿𝙀 𝙐𝙎𝙊: ${usedPrefix + command} https://tiktokxxxx\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊\nꨄ︎${usedPrefix + command} https://vm.tiktok.com/ZMLUb9M5j/`
if (!args[0].match(/tiktok/gi)) throw `𝙁𝘼𝙇𝙇𝙊 𝘼𝙇 𝘿𝙀𝙏𝙀𝘾𝙏𝘼𝙍 𝙐𝙍𝙇 𝘿𝙀 𝙏𝙄𝙆𝙏𝙊𝙆, 𝘾𝙊𝙈𝙋𝙍𝙐𝙀𝘽𝙀 𝙌𝙐𝙀 𝙎𝙀𝘼 𝘿𝙀 𝙏𝙄𝙆𝙏𝙊𝙆`
let res = await fetch("https://api-alc.herokuapp.com/api/download/tiktok?url="+args[0]+"&apikey=ConfuMods")
let json = await res.json()
conn.sendFile(m.chat, json.result.sin_marca, 'error.mp4', `   𝘼𝙌𝙐𝙄 𝙏𝙄𝙀𝙉𝙀𝙎 𝙀𝙇 𝙏𝙄𝙆𝙏𝙊𝙆 𝘼𝙈𝙊𝙍🤭\nꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏`, m)}
handler.command = /^(tik(tok)?(dl)?)$/i
module.exports = handler
