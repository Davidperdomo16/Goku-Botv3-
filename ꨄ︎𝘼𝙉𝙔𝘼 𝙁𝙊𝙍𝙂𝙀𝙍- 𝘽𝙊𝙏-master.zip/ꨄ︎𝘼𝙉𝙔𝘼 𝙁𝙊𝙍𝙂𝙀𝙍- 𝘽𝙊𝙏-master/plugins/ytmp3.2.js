let fetch = require('node-fetch')
let handler = async (m, { conn, args, usedPrefix, command, text }) => {
if (!args[0]) throw `𝙄𝙉𝙂𝙍𝙀𝙎𝙀 𝙀𝙇 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙔𝙊𝙐𝙏𝙐𝘽𝙀🥰`
let res = await fetch("https://api.lolhuman.xyz/api/ytaudio?apikey=85faf717d0545d14074659ad&url="+args[0])
let json = await res.json()
conn.sendFile(m.chat, json.result.link.link, 'error.mp3', '', m, false, { mimetype: 'audio/mp4' })}
handler.command = /^(ytmp3.2?)$/i
module.exports = handler
