let fetch = require('node-fetch')
let handler = async(m, { conn }) => {
  let res = await fetch('https://api.waifu.pics/sfw/waifu')
  if (!res.ok) throw await res.text()
  let json = await res.json()
  if (!json.url) throw '𝙀𝙍𝙍𝙊𝙍!'
  conn.sendFile(m.chat, json.url, '', '𝘼~𝘼𝙍𝘼 𝘼𝙍𝘼 𝙎𝙀𝙈𝙋𝘼𝙄', m)
}
handler.help = ['waifu']
handler.tags = ['General']
handler.command = /^(waifu)$/i

module.exports = handler
