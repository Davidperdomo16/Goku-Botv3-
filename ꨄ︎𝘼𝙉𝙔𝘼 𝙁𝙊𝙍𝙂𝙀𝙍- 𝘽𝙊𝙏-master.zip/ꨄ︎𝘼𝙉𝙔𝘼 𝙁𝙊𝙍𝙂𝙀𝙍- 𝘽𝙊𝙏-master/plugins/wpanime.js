const { MessageType } = require('@adiwajshing/baileys')
const fetch = require('node-fetch')

let handler = async (m, { conn }) => {
    try {
        let res = await fetch(global.API('xteam', '/randomimage/wpmobile', {}, 'APIKEY'))
        let img = await res.buffer()
        conn.sendMessage(m.chat, img, MessageType.image, {
            quoted: m, caption: '🖤ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏🖤'
        })
    } catch (e) {
        console.log(e)
        throw '😔𝙀𝙇 𝙋𝙍𝙊𝙋𝙄𝙀𝙏𝘼𝙍𝙄𝙊 𝙉𝙊 𝙃𝘼 𝙋𝘼𝙂𝘼𝘿𝙊 𝙇𝘼 𝙁𝘼𝘾𝙏𝙐𝙍𝘼 𝘿𝙀 𝙀𝙎𝙏𝘼 𝙊𝙋𝘾𝙄𝙊𝙉😔'
    }
}
handler.help = ['wallpaperanime']
handler.tags = ['internet']
handler.command = /^(wallpaper|wp)anime$/i
handler.limit = false
module.register = false
module.group = true

module.exports = handler