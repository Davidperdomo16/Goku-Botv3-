let handler = async (m, { conn, command, usedPrefix }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
conn.send3Button(m.chat, `
▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄
乡❤️ 𝙃𝙊𝙇𝘼 𝙈𝙄 𝘼𝙈𝙊𝙍 ❤乡

𐎽░𝘼𝙉𝙔𝘼_𝙁𝙊𝙍𝙂𝙀𝙍_𝘽𝙊𝙏░
𐎽𝙀𝙎𝙏𝙊𝙔 𝘼 𝙎𝙐𝙎 𝙊𝙍𝘿𝙀𝙉𝙀𝙎 𝘼𝙈𝙊𝙍😍
𐎽𝘼𝘾𝙏𝙄𝙑𝙊 𝘿𝙐𝙍𝘼𝙉𝙏𝙀
𐎽1:15:12
𐎽𝘽𝙊𝙏 𝘿𝙀 𝙐𝙎𝙊 𝙋𝙐𝘽𝙇𝙄𝘾𝙊✿

▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄
`.trim(), 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍-𝘽𝙊𝙏', '⚡ 𝙈𝙀𝙉𝙐 ⚡', `${usedPrefix}menu`, '🧸️ 𝙈𝙀𝙉𝙐 𝙎𝙄𝙈𝙋𝙇𝙀 🧸️', `${usedPrefix}menusimple`, '❤️️ 𝙈𝙀𝙉𝙐 𝘼𝙐𝘿𝙄𝙊𝙎 ❤️️', `${usedPrefix}menuaudios`, m, false, { contextInfo: { mentionedJid }})}
handler.command = /^(estado|status|estate|state|stado|stats)$/i
module.exports = handler
