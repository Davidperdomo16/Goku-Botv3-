const axios = require('axios')
let handler = async(m, { conn, usedPrefix, command }) => {
let res = await axios("https://meme-api.herokuapp.com/gimme/Cristianoronaldo")
let json = res.data
let url = json.url
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
conn.sendButtonImg(m.chat, url, " 🥵 𝙃𝘼𝙔 𝙈𝙄 𝙈𝘼𝘿𝙍𝙀 𝙀𝙇 𝘽𝙄𝘾𝙃𝙊 𝙎𝙄𝙄𝙄𝙐𝙐𝙐𝙐𝙐 🥵", 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏', '⚽ 𝙎𝙄𝙂𝙐𝙄𝙀𝙉𝙏𝙀 ⚽', `${usedPrefix + command}`, m, false, { contextInfo: { mentionedJid }})}
handler.command = /^(cristianoronaldo)$/i
module.exports = handler
