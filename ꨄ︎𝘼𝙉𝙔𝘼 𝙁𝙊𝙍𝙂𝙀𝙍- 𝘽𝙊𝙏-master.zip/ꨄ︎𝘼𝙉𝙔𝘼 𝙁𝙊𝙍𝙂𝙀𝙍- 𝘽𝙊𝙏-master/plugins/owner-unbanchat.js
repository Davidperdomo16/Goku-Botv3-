let handler = async (m, { conn }) => {
  if (!(m.chat in global.DATABASE._data.chats)) return m.reply('*Este chat no está registrado en la base de datos!*')
  let chat = global.DATABASE._data.chats[m.chat]
  if (!chat.isBanned) return m.reply('𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝙉𝙊 𝙀𝙎𝙏𝘼 𝙋𝙍𝙊𝙃𝙄𝘽𝙄𝘿𝙊')
  chat.isBanned = false
  m.reply('✅ 𝘾𝙃𝘼𝙏 𝘿𝙀𝙎𝘽𝘼𝙉𝙀𝘼𝘿𝙊 𝙀𝙓𝙄𝙏𝙊𝙎𝘼𝙈𝙀𝙉𝙏𝙀')
}
handler.command = /^unbanchat2$/i
handler.rowner = true
module.exports = handler
