let { MessageType } = require('@adiwajshing/baileys')
let handler = async (m, { conn, text}) => {
    if (!text) throw '𝘼 𝙌𝙐𝙄𝙀𝙉 𝘿𝙀𝙎𝙀𝘼 𝘽𝘼𝙉𝙀𝘼𝙍? 𝙀𝙏𝙄𝙌𝙐𝙀𝙏𝙀 𝘼 𝙇𝘼 𝙋𝙀𝙍𝙎𝙊𝙉𝘼 𝘾𝙊𝙉 𝙀𝙇 @'
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '𝙀𝙏𝙄𝙌𝙐𝙀𝙏𝙀 𝘼 𝙐𝙉𝘼 𝙋𝙀𝙍𝙎𝙊𝙉𝘼 𝘾𝙊𝙉 𝙀𝙇 @'
    let users = global.DATABASE._data.users
    users[who].banned = false
    conn.reply(m.chat, `✅ 𝙐𝙎𝙐𝘼𝙍𝙄𝙊 𝘽𝘼𝙉𝙀𝘼𝘿𝙊 𝙀𝙓𝙄𝙏𝙊𝙎𝘼𝙈𝙀𝙉𝙏𝙀`, m)
}
handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^unbanuser$/i
handler.rowner = true

module.exports = handler
