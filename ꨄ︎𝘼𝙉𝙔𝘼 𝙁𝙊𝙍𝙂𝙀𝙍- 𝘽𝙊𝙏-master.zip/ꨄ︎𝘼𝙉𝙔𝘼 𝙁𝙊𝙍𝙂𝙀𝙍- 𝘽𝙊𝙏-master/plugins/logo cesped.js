let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
response = args.join(' ').split('|')
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤:)\n𝙀𝙟𝙚𝙢𝙥𝙡𝙤*\n#𝙡𝙤𝙜𝙤𝙘𝙚𝙨𝙥𝙚𝙙 𝙖𝙣𝙮𝙖*'        
let res = `https://api-alc.herokuapp.com/api/photooxy/under-grass?texto=${response[0]}&apikey=ConfuMods`
conn.sendFile(m.chat, res, 'error.jpg', `*Logo terminado*`, m, false)}
handler.command = /^(undergrass|logocesped|cesped)$/i
module.exports = handler
