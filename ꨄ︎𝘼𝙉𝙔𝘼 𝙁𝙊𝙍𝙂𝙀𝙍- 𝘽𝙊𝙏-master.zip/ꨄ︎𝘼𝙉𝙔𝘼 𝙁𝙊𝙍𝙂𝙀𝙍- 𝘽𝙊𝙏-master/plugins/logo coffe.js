let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
response = args.join(' ').split('|')
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤\n𝙚𝙟𝙚𝙢𝙥𝙡𝙤:\n#𝙘𝙤𝙛𝙛𝙚 𝙖𝙣𝙮𝙖'        
let res = `https://api-alc.herokuapp.com/api/photooxy/coffee-cup?texto=${response[0]}&apikey=ConfuMods`
conn.sendFile(m.chat, res, 'error.jpg', `𝙇𝙤𝙜𝙤 𝙩𝙚𝙧𝙢𝙞𝙣𝙖𝙙𝙤✅`, m, false)}
handler.command = /^(coffe|logocoffe)$/i
module.exports = handler
