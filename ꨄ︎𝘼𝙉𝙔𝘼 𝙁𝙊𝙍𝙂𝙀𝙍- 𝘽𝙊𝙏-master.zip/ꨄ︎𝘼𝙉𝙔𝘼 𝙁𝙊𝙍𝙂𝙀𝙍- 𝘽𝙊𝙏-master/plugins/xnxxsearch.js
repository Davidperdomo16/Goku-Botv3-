let fetch = require("node-fetch")
let axios = require("axios")
let kntl = require("../src/kntl.json")
let handler = async (m, { conn, text }) => {
  let api = (kntl.lolkey)
  let chat = global.DATABASE.data.chats[m.chat]
     try {
      let res = await axios.get(`https://api.lolhuman.xyz/api/xnxxsearch?apikey=e1a815979e6adfc071b7eafc&query=${text}`)
      let json = res.data
      //let ress = json.result
      let hsl = `😏 𝙀𝙉𝘾𝙊𝙉𝙏𝙍𝙀 𝙇𝙊 𝙎𝙄𝙂𝙐𝙄𝙀𝙉𝙏𝙀 😏\n\n`
      for (let i = 0; i < json.result.length; i++) {
           hsl += `🤔𝙏𝙄𝙏𝙐𝙇𝙊: ${json.result[i].title}\n`
           hsl += `👀𝙑𝙄𝙎𝙏𝘼𝙎: ${json.result[i].views}\n`
           hsl += `⏳𝘿𝙐𝙍𝘼𝘾𝙄𝙊𝙉 ${json.result[i].duration}\n`
           hsl += `🛑𝙐𝙎𝙀 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊:\n`
           hsl += `#𝙓𝙉𝙓𝙓 ${json.result[i].link}\n`
           hsl += ` ▶️𝙋𝘼𝙍𝘼 𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝙍 𝙀𝙇 𝙑𝙄𝘿𝙀𝙊▶️\n\n`
         }
           hsl += 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏'
        conn.reply(m.chat, hsl, m)
    }catch(e){
        m.reply("𝘼𝙇𝙂𝙊 𝙎𝘼𝙇𝙄𝙊 𝙈𝘼𝙇 𝙑𝙐𝙀𝙇𝙑𝙀 𝘼 𝙄𝙉𝙏𝙀𝙉𝙏𝘼𝙍𝙇𝙊\n\n*𝙎𝙄 𝙀𝙇 𝙀𝙍𝙍𝙊𝙍 𝙎𝙀 𝙍𝙀𝙋𝙄𝙏𝙀, 𝙋𝙐𝙀𝘿𝙀 𝙎𝙀𝙍 𝙌𝙐𝙀 𝙀𝙇 𝙇𝙄𝙈𝙄𝙏𝙀 𝘿𝙀 𝙐𝙎𝙊 𝘿𝙀𝙇 𝙎𝙀𝙍𝙑𝙄𝘿𝙊𝙍 𝘿𝙄𝘼𝙍𝙄𝙊 𝙃𝘼𝙔𝘼 𝙏𝙀𝙍𝙈𝙄𝙉𝘼𝘿𝙊, 𝘾𝘼𝘿𝘼 𝘿𝙄𝘼 𝙎𝙀 𝙍𝙀𝙎𝙏𝘼𝘽𝙇𝙀𝘾𝙀 𝙀𝙇 𝙇𝙄𝙈𝙄𝙏𝙀 ")
        console.log(e)
     }
   }
handler.command = /^(xnxxsearch|searchxnxx)$/
handler.premium = false
module.exports = handler