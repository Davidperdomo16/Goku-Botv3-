let yts = require('yt-search')
let handler = async (m, { text }) => {
  if (!text) return m.reply('𝙔 𝙀𝙇 𝙏𝙀𝙓𝙏𝙊 🤔')
  let results = await yts(text)
  let teks = results.all.map(v => {
    switch (v.type) {
      case '𝙑𝙄𝘿𝙀𝙊': return `
😎 ${v.title}
👾 (${v.url})
⏳  𝘿𝙐𝙍𝘼𝘾𝙄𝙊𝙉: ${v.timestamp}
🕘  𝙁𝙀𝘾𝙃𝘼: 𝘿𝙀 𝙎𝙐𝘽𝙄𝘿𝘼: ${v.ago}
👁️👄👁️  𝙑𝙄𝙎𝙏𝘼𝙎: ${v.views} 
      `.trim()
      case 'channel': return `
😎 ${v.name}
👾 (${v.url})
➡️ 𝙎𝙐𝘽𝙎𝘾𝙍𝙄𝙋𝙏𝙊𝙍𝙀𝙎: ${v.subCountLabel}  (${v.subCount}) 
📽️ 𝙑𝙄𝘿𝙀𝙊𝙎: ${v.videoCount}  
`.trim()
    }
  }).filter(v => v).join('\n========================\n')
  m.reply(teks)
}
handler.command = /^yts(earch)?$/i
module.exports = handler
