let handler = async (m, { conn, text}) => {
    if (!text) throw '𝘼 𝙌𝙐𝙄𝙀𝙉 𝙌𝙐𝙄𝙀𝙍𝙀 𝘽𝘼𝙉𝙀𝘼𝙍 𝘽𝘽?'
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '𝙀𝙏𝙄𝙌𝙐𝙀𝙏𝙀 𝘼𝙇𝙂𝙐𝙉 𝙐𝙎𝙐𝘼𝙍𝙄𝙊'
    let users = global.DATABASE._data.users
    users[who].banned = true
    conn.reply(m.chat, `✅ 𝙀𝙇 𝙐𝙎𝙐𝘼𝙍𝙄𝙊 𝙁𝙐𝙀 𝘽𝘼𝙉𝙀𝘼𝘿𝙊 𝘾𝙊𝙉 𝙀𝙓𝙄𝙏𝙊 ✅\n\n⚠️ 𝙀𝙇 𝙐𝙎𝙐𝘼𝙍𝙄𝙊 𝙉𝙊 𝙏𝙀𝙉𝘿𝙍𝘼 𝙋𝙀𝙍𝙈𝙄𝙎𝙊 𝙋𝘼𝙍𝘼 𝙐𝙎𝘼𝙍 𝙀𝙇 𝘽𝙊𝙊𝙏 ⚠️`, m)
}
handler.help = ['banuser']
handler.tags = ['General']
handler.command = /^banuser$/i
handler.rowner = true

module.exports = handler