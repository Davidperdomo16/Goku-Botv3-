process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const { servers, yta } = require('../lib/y2mate')
let handler = async (m, { conn, args, isPrems, isOwner }) => {
  if (!args || !args[0]) return m.reply('*[❗] 𝙄𝙉𝙎𝙀𝙍𝙏𝙀 𝙐𝙉 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙔𝙊𝙐𝙏𝙐𝘽𝙀\n\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊:\n#dlaudio https://www.youtube.com/watch?v=8jvDzEIVpjg')
  let chat = global.DATABASE._data.chats[m.chat]
  let server = (args[1] || servers[0]).toLowerCase()
  let { dl_link, thumb, title, filesize, filesizeF} = await yta(args[0], servers.includes(server) ? server : servers[0])
  //let isLimit = (isPrems || isOwner ? 99 : limit) * 1024 < filesize
  //m.reply(isLimit ? `*🔰 Tamaño del audio: ${filesizeF}*\n\n*✳️ Tamaño máximo para poder enviar: ${limit} MB*\n\n*Puede descargar usted mismo el audio a través de este enlace:*\n*→ ${dl_link}*\n*👉🏻 Al entrar automáticamente se le descargará*` : global.wait)
  await m.reply(`✅️ 𝙀𝙎𝙋𝙀𝙍𝙀 𝙐𝙉 𝙈𝙊𝙈𝙀𝙉𝙏𝙊 𝙀𝙎𝙏𝙊𝙔 𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝙉𝘿𝙊 𝙀𝙇 𝘼𝙐𝘿𝙄𝙊 ✅\n\n*⚠️ 𝙎𝙄 𝙎𝙐 𝘼𝙐𝘿𝙄𝙊 𝙉𝙊 𝙀𝙎 𝙀𝙉𝙑𝙄𝘼𝘿𝙊 𝘿𝙀𝙎𝙋𝙐𝙀𝙎 𝘿𝙀 5 𝙈𝙄𝙉𝙐𝙏𝙊𝙎, 𝙋𝙊𝙍 𝙁𝘼𝙑𝙊𝙍 𝙄𝙉𝙏𝙀𝙉𝙏𝙀 𝙉𝙐𝙀𝙑𝘼𝙈𝙀𝙉𝙏𝙀, 𝙎𝙄 𝙀𝙇 𝙀𝙍𝙍𝙊𝙍 𝙎𝙀 𝙍𝙀𝙋𝙄𝙏𝙀 𝙋𝙊𝙍𝙁𝘼𝙑𝙊𝙍 𝙄𝙉𝙏𝙀𝙉𝙏𝙀 𝘾𝙊𝙉 𝙊𝙏𝙍𝙊 𝘼𝙐𝘿𝙄𝙊`)
  //conn.sendFile(m.chat, thumb, 'thumbnail.jpg', `
//❒═════❬ YTMP3 ❭═════╾❒
//┬
//├‣*🤔𝙉𝙊𝙈𝘽𝙍𝙀: ${title}
//┴
//├‣*🗂️𝙏𝘼𝙈𝘼𝙉̃𝙊: ${filesizeF}
//┴
//├‣*${isLimit ? 'Pakai ': ''}Link de descarga (usar si el Bot no manda el archivo mp3):* ${dl_link}
//┴
//`.trim(), m)
conn.sendFile(m.chat, dl_link, title + '.mp3', `
❒═════❬ YTMP3 ❭═════╾❒
┬
├‣🤔𝙉𝙊𝙈𝘽𝙍𝙀: ${title}
┴
├‣🗂️𝙏𝘼𝙈𝘼𝙉̃𝙊: ${filesizeF}
┴
`.trim(), m, null, {
//  asDocument: chat.useDocument
})
}
handler.command = /^dlyt|dlaudio|dlytaud|dlaud$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0

module.exports = handler
