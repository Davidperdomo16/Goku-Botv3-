let fetch = require('node-fetch')
let handler = async (m, { conn, usedPrefix, command, text }) => {
if (!text) throw `*Formato de uso: ${usedPrefix + command} Nombre de la canción o video*\n*Ejemplo:*\n*${usedPrefix + command} Beret ojala*`
let res = await fetch("https://api-alc.herokuapp.com/api/download/play-mp4?query="+text+"&apikey=ConfuMods")
let json = await res.json()
conn.sendFile(m.chat, json.link, 'error.mp4', `   𝘼𝙌𝙐𝙄 𝙏𝙄𝙀𝙉𝙀𝙎 𝙀𝙇 𝙑𝙄𝘿𝙀𝙊 𝙋𝘼𝙋𝙄 😏🥰 :D\n ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏`, m)}
handler.command = /^(play4)$/i
module.exports = handler
