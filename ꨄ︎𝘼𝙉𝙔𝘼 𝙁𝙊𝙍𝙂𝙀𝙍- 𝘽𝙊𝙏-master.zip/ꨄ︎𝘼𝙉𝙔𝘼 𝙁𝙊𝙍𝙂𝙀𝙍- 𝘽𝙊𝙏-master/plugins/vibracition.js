let { MessageType, Presence, mimetype } = require('@adiwajshing/baileys')
let ffmpeg = require('fluent-ffmpeg');
let fetch = require('node-fetch');
let ftype = require('file-type');
let fs = require('fs');
let { exec } = require('child_process');

let handler = async(m, { conn, text, args }) => {
if (!text) throw '𝘾𝙐𝘼𝙉𝙏𝙊 𝘿𝙀𝙎𝙀𝘼 𝙋𝙊𝙉𝙀𝙍𝙇𝙀?\n*_𝙐𝙎𝙀 𝙐𝙉 𝙉𝙐𝙈𝙀𝙍𝙊 𝙀𝙉𝙏𝙍𝙀 𝙀𝙇 1 𝙔 𝙀𝙇 100\n\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊: #𝙑𝙄𝘽𝙍𝘼𝘾𝙄𝙊𝙉 10\n\n𝙉𝙊𝙏𝘼: 𝙍𝙀𝘾𝙐𝙀𝙍𝘿𝙀 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝙀 𝘼 𝙐𝙉 𝘼𝙐𝘿𝙄𝙊 𝙊 𝙉𝙊𝙏𝘼 𝘿𝙀 𝙑𝙊𝙕'
     await m.reply('⏳𝙋𝙍𝙊𝘾𝙀𝙎𝘼𝙉𝘿𝙊 𝘼𝙐𝘿𝙄𝙊...')
          if (!m.quoted) return conn.reply(m.chat, '𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼 𝙐𝙉 𝘼𝙐𝘿𝙄𝙊 𝙊 𝙉𝙊𝙏𝘼 𝘿𝙀 𝙑𝙊𝙕!', m)
          let type = Object.keys(m.message)[0]
          let content = JSON.stringify(m.message)
          let isMedia = (type === 'imageMessage' || type === 'videoMessage')
          let isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
                  if (!isQuotedAudio) return m.reply('𝙄𝙏𝙐 𝘼𝙐𝘿𝙄𝙊?')
                                let encmedia = JSON.parse(JSON.stringify(m).replace('quotedM','m')).message.extendedTextMessage.contextInfo
                                let media = await conn.downloadAndSaveMediaMessage(encmedia)
                                  let ran = getRandom('.mp3')
                                    exec(`ffmpeg -i ${media} -filter_complex "vibrato=f=${text}" ${ran}`, (err, stderr, stdout) => {
                                      fs.unlinkSync(media)
                                      if (err) return reply('Ada yang Erorr!')
                                      let tupai = fs.readFileSync(ran)
                                      conn.sendFile(m.chat, tupai, 'tupai.mp3', '', m, false, { ptt: true })
                                      fs.unlinkSync(ran)
           })
}
handler.help = ['vibration (reply audio)']
handler.tags = ['audio']
handler.command = /^(vibracion)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.register = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0
handler.limit = false

module.exports = handler

const getRandom = (ext) => {
  return `${Math.floor(Math.random() * 10000)}${ext}`
}