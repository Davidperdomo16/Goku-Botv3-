//NO MODIFIQUES EL NÚMERO DEL CREADOR NI EL NOMBRE.. SOLO AGREGA LA INFORMACIÓN QUE TU QUIERAS O EDITALO A TU MANERA PERO DEJANDO LOS CREDITOS <3 
//PUEDES AGREGAR OTRA FILAS DE PAYPAL, GRUPOS, PERO DEJA ALGUNOS CREDITOS, YA QUE ES LA UNICA MANERA DE INGRESOS DEL BOT
//SI VAS A MODIFICAR TODO Y HACER PASAR COMO SI FUERA TU BOT (CREADO POR TI) SOLO TE PIDO QUE SI ESTA EN TUS POSIBILIDADES DONES UN POCO
//LLEVO AL REDEDOR DE 1 AÑO Y MEDIO EN LA ELABORACION DE ESTE BOT, SI TU LO EDITAS EN UNA SEMANA NO ERES TU EL CREADOR, SI LO EDITAS TOTALMENTE A TU MANERA SERIA UTULIZADO MI BOT COMO BASE Y AHI SI LO SERIAS  

let fs = require('fs')
let fetch = require('node-fetch')
let moment = require('moment-timezone')
let path = require('path')
let util = require('util')
let handler = async (m, { conn, usedPrefix }) => {
let pp = './Menu2.jpg'
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let username = conn.getName(who)
//let vn = './media/mariana.mp3'
let menu =`
╭══༄𖣘★𖣘★𖣘★𖣘★𖣘 〙═╮
𐎽═  ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏 🥰
𐎽✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎
𐎽➤ 😏❤️𝙃𝙤𝙡𝙞 𝙖𝙢𝙤𝙧, ${username}
𐎽≡≡≡≡≡≡≡≡≡≡≡≡≡≡
𐎽➤ 👸 𝙘𝙧𝙚𝙖𝙙𝙤𝙧𝙖 𝙙𝙚𝙡 𝙗𝙤𝙩: 𝙎𝙊𝙁𝙄𝘼🤫 
𐎽➤ 𝙉𝙪𝙢𝙚𝙧𝙤 𝙙𝙚 𝙡𝙖 𝙘𝙧𝙚𝙖𝙙𝙤𝙧𝙖: wa.me/50495086382 (𝙉𝙤 𝘽𝙤𝙩)
𐎽➤ 𝙉𝙪𝙢𝙚𝙧𝙤 𝙤𝙛𝙞𝙘𝙞𝙖𝙡 𝙙𝙚𝙡 𝘽𝙤𝙩: wa.me/50498965677
𐎽✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎✈︎
╰══╡𖣘✰𖣘✰𖣘✰𖣘✰𖣘╞══╯
┏━━━━━━━━━━━━━┓
┃ ༆𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝘾𝙄𝙊𝙉|𝙈𝙀𝙉𝙐𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟ℹ️️ _${usedPrefix}sc_
┣ ඬ⃟ℹ️️ _${usedPrefix}donar_
┣ ඬ⃟ℹ️️ _${usedPrefix}infobot_
┣ ඬ⃟ℹ️️ _${usedPrefix}grupos_
┣ ඬ⃟ℹ️ _${usedPrefix}instalarbot_
┣ ඬ⃟ℹ️ _${usedPrefix}menusimple_
┣ ඬ⃟ℹ️️ _${usedPrefix}menuaudios_
┣ ඬ⃟ℹ️️ _${usedPrefix}menu2_
┣ ඬ⃟ℹ️️ _${usedPrefix}labiblia_
┣ ඬ⃟ℹ️ _${usedPrefix}estado_
┣ ඬ⃟ℹ️ _Bot_
┣ ඬ⃟ℹ️ _¿Qué es un Bot?_
┣ ඬ⃟ℹ️ _Codigos para audios_
┣ ඬ⃟ℹ️ _Términos y condiciones_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃ ༆𝙍𝙀𝙋𝙊𝙍𝙏𝘼 𝙁𝘼𝙇𝙇𝙊𝙎 𝘿𝙀 𝘼𝙇𝙂𝙐𝙉 𝘾𝙊𝙈𝘼𝙉𝘿𝙊༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┃ 𝙍𝙚𝙥𝙤𝙧𝙩𝙖 𝙘𝙪𝙖𝙡𝙦𝙪𝙞𝙚𝙧 𝙘𝙤𝙢𝙖𝙣𝙙𝙤 𝙦𝙪𝙚 𝙛𝙖𝙡𝙡𝙚 𝙥𝙖𝙧𝙖 𝙖𝙨𝙞 𝙨𝙤𝙡𝙪𝙘𝙞𝙤𝙣𝙖𝙧𝙡𝙤
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟📬 _${usedPrefix}bug *comando con fallas*_
┣ ඬ⃟📬 _${usedPrefix}report *comando con fallas*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃ ༆𝙐𝙉𝙀 𝙐𝙉 𝘽𝙊𝙏 𝘼 𝙏𝙐 𝙂𝙍𝙐𝙋𝙊༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🤖 _${usedPrefix}join *link del grupo*_ 
┣ ඬ⃟🤖 _${usedPrefix}bots_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝙏𝙊𝙋𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🎖️ _${usedPrefix}top10gays_
┣ ඬ⃟🎖️ _${usedPrefix}toplind@s_
┣ ඬ⃟🎖️ _${usedPrefix}topput@s_
┣ ඬ⃟🎖️ _${usedPrefix}toppajer@s_
┣ ඬ⃟🎖️ _${usedPrefix}topotakus_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝙉𝙐𝙈𝙀𝙍𝙊 𝘿𝙀𝙇 𝘾𝙍𝙀𝘼𝘿𝙊𝙍༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟👻 _${usedPrefix}owner_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝙅𝙐𝙀𝙂𝙊𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🕹 _${usedPrefix}math *modo*_
┣ ඬ⃟🎮 _${usedPrefix}ttt *nombre del la sala*_
┣ ඬ⃟🕹 _${usedPrefix}delttt *nombre del la sala*_
┣ ඬ⃟🎮 _${usedPrefix}2gay *@tag*_
┣ ඬ⃟🕹 _${usedPrefix}gay *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}lesbi *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}pajero *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}pajera *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}puta *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}puto *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}rata *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}manco *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}manca *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}formarpareja_
┣ ඬ⃟🕹 _${usedPrefix}dado_
┣ ඬ⃟🎮 _${usedPrefix}simsimi *texto*_
┣ ඬ⃟🕹 _${usedPrefix}formartrio_
┣ ඬ⃟🎮 _${usedPrefix}love *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}amigorandom_
┣ ඬ⃟🎮 _${usedPrefix}slot *cantidad*_
┣ ඬ⃟🕹 _${usedPrefix}ppt *piedra / papel / tijera*_
┣ ඬ⃟🎮 _${usedPrefix}prostituta *@tag / nombre*_
┣ ඬ⃟🕹 _${usedPrefix}prostituto *@tag / nombre*_
┣ ඬ⃟🎮 _${usedPrefix}doxear *@tag / nombre*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟📥 _${usedPrefix}imagen *texto*_
┣ ඬ⃟📥 _${usedPrefix}ytsearch *texto*_
┣ ඬ⃟📥 _${usedPrefix}dlaudio *link yt*_
┣ ඬ⃟📥 _${usedPrefix}dlvid *link yt*_
┣ ඬ⃟📥 _${usedPrefix}ytmp3 *link yt*_
┣ ඬ⃟📥 _${usedPrefix}ytmp4 *link yt*_
┣ ඬ⃟📥 _${usedPrefix}ytmp3.2 *link yt*_
┣ ඬ⃟📥 _${usedPrefix}ytmp4.2 *link yt*_
┣ ඬ⃟📥 _${usedPrefix}play *titulo del audio*_
┣ ඬ⃟📥 _${usedPrefix}play.1 *titulo del audio*_
┣ ඬ⃟📥 _${usedPrefix}play2 *titulo del video*_
┣ ඬ⃟📥 _${usedPrefix}play.2 *titulo del video*_
┣ ඬ⃟📥 _${usedPrefix}play3 *titulo del audio/video*_
┣ ඬ⃟📥 _${usedPrefix}play4 *titulo del video*_
┣ ඬ⃟📥 _${usedPrefix}letra *nombredelacanción*_
┣ ඬ⃟📥 _${usedPrefix}google *texto*_
┣ ඬ⃟📥 _${usedPrefix}googlef *texto*_
┣ ඬ⃟📥 _${usedPrefix}wikipedia *palabra clave*_
┣ ඬ⃟📥 _${usedPrefix}pinterestvideo *link de pinterest*_
┣ ඬ⃟📥 _${usedPrefix}tiktok *link*_
┣ ඬ⃟📥 _${usedPrefix}acortar *link*_
┣ ඬ⃟📥 _${usedPrefix}pinterest *texto*_
┣ ඬ⃟📥 _${usedPrefix}xnxx *link de xnxx*_
┣ ඬ⃟📥 _${usedPrefix}xnxxsearch *texto*_
┣ ඬ⃟📥 _${usedPrefix}ssweb *link*_
┣ ඬ⃟📥 _${usedPrefix}igstory *username*_
┣ ඬ⃟📥 _${usedPrefix}igstalk *username*_
┣ ඬ⃟📥 _${usedPrefix}animeinfo *nombre del anime*_
┣ ඬ⃟📥 _${usedPrefix}twvid *link de video de twitter*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃   ༆𝙂𝙀𝙎𝙏𝙄𝙊𝙉 𝘿𝙀 𝙂𝙍𝙐𝙋𝙊𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟💎 _${usedPrefix}admins *texto*_ 
┣ ඬ⃟💎 _${usedPrefix}añadir *numero*_ 
┣ ඬ⃟💎 _${usedPrefix}sacar @tag_
┣ ඬ⃟💎 _${usedPrefix}save *@tag + nombre de contacto*_
┣ ඬ⃟💎 _${usedPrefix}daradmin *@tag*_
┣ ඬ⃟💎 _${usedPrefix}quitaradmin *@tag*_
┣ ඬ⃟💎 _${usedPrefix}grupo *abrir / cerrar*_
┣ ඬ⃟💎 _${usedPrefix}enable nsfw_
┣ ඬ⃟💎 _${usedPrefix}disable nsfw_
┣ ඬ⃟💎 _${usedPrefix}enable welcome_
┣ ඬ⃟💎 _${usedPrefix}disable welcome_
┣ ඬ⃟💎 _${usedPrefix}enable antilink_
┣ ඬ⃟💎 _${usedPrefix}disable antilink_
┣ ඬ⃟💎 _${usedPrefix}enable antilink2_
┣ ඬ⃟💎 _${usedPrefix}disable antilink2_
┣ ඬ⃟💎 _${usedPrefix}enable delete_
┣ ඬ⃟💎 _${usedPrefix}disable  delete_ 
┣ ඬ⃟💎 _${usedPrefix}link_
┣ ඬ⃟💎 _${usedPrefix}notificar *texto*_
┣ ඬ⃟💎 _${usedPrefix}setname *Nuevo nombre del grupo*_
┣ ඬ⃟💎 _${usedPrefix}setdesc *Nueva descripción del grupo*_
┣ ඬ⃟💎 _${usedPrefix}infogrupo_
┣ ඬ⃟💎 _${usedPrefix}invocar *texto*_
┣ ඬ⃟💎 _${usedPrefix}del *responder a un mensaje del bot*_
┣ ඬ⃟💎 _${usedPrefix}fantasmas_
┣ ඬ⃟💎 _${usedPrefix}banchat_
┣ ඬ⃟💎 _${usedPrefix}unbanchat_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝘾𝙍𝙀𝘼𝘿𝙊𝙍𝙀𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🧧 _${usedPrefix}s_
┣ ඬ⃟🧧 _${usedPrefix}sticker_
┣ ඬ⃟🧧 _${usedPrefix}semoji_
┣ ඬ⃟🧧 _${usedPrefix}wasted_
┣ ඬ⃟🧧 _${usedPrefix}stonks_
┣ ඬ⃟🧧 _${usedPrefix}trash_
┣ ඬ⃟🧧 _${usedPrefix}rainbow_
┣ ඬ⃟🧧 _${usedPrefix}circle_
┣ ඬ⃟🧧 _${usedPrefix}trigger_
┣ ඬ⃟🧧 _${usedPrefix}stickermaker_
┣ ඬ⃟🧧 _${usedPrefix}attp *texto*_
┣ ඬ⃟🧧 _${usedPrefix}style *texto*_
┣ ඬ⃟🧧 _${usedPrefix}attp2 *texto*_
┣ ඬ⃟🧧 _${usedPrefix}stickerfilter_
┣ ඬ⃟🧧 _${usedPrefix}trigger *@tag*_
┣ ඬ⃟🧧 _${usedPrefix}mp3 *responde a un video*_
┣ ඬ⃟🧧 _${usedPrefix}img *responde a un sticker*_
┣ ඬ⃟🧧 _${usedPrefix}blur *responde a una imagen*_
┣ ඬ⃟🧧 _${usedPrefix}swm *link de imagen de google*_
┣ ඬ⃟🧧 _${usedPrefix}gif *responde a un sticker/video*_
┣ ඬ⃟🧧 _${usedPrefix}tovideo *responde a una nota de voz*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝙍𝘼𝙈𝘿𝙊𝙉/𝙀𝙓𝙏𝙍𝘼𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟👾 _${usedPrefix}frase_
┣ ඬ⃟👾 _${usedPrefix}futbol_
┣ ඬ⃟👾 _${usedPrefix}Messi_
┣ ඬ⃟👾 _${usedPrefix}animal_
┣ ඬ⃟👾 _${usedPrefix}meme_
┣ ඬ⃟👾 _${usedPrefix}meme2_
┣ ඬ⃟👾 _${usedPrefix}meme3_
┣ ඬ⃟👾 _${usedPrefix}cat_
┣ ඬ⃟👾 _${usedPrefix}dog_
┣ ඬ⃟👾 _${usedPrefix}pikachu_
┣ ඬ⃟👾 _${usedPrefix}waifu_
┣ ඬ⃟👾 _${usedPrefix}blackpink_
┣ ඬ⃟👾 _${usedPrefix}reto_
┣ ඬ⃟👾 _${usedPrefix}verdad_
┣ ඬ⃟👾 _${usedPrefix}imagenrandom_
┣ ඬ⃟👾 _${usedPrefix}neko_
┣ ඬ⃟👾 _${usedPrefix}lolivid_
┣ ඬ⃟👾 _${usedPrefix}iqtest_
┣ ඬ⃟👾 _${usedPrefix}kpopitzy_
┣ ඬ⃟👾 _${usedPrefix}navidad_
┣ ඬ⃟👾 _${usedPrefix}loli_
┣ ඬ⃟👾 _${usedPrefix}gawrgura_
┣ ඬ⃟👾 _${usedPrefix}miku_
┣ ඬ⃟👾 _${usedPrefix}nyan_
┣ ඬ⃟👾 _${usedPrefix}pat_
┣ ඬ⃟👾 _${usedPrefix}itachi_
┣ ඬ⃟👾 _${usedPrefix}slap_
┣ ඬ⃟👾️ _${usedPrefix}pat_
┣ ඬ⃟👾 _${usedPrefix}perfil_
┣ ඬ⃟👾 _${usedPrefix}scan_
┣ ඬ⃟👾 _${usedPrefix}kpop_
┣ ඬ⃟👾 _${usedPrefix}qr *texto*_
┣ ඬ⃟👾 _${usedPrefix}afk *motivo*_
┣ ඬ⃟👾 _${usedPrefix}CristianoRonaldo_
┣ ඬ⃟👾 _${usedPrefix}pregunta *pregunta*_
┣ ඬ⃟👾 _${usedPrefix}mention *texto*_
┣ ඬ⃟👾 _${usedPrefix}spamchat *texto*_
┣ ඬ⃟👾 _${usedPrefix}traducir es *texto*_
┣ ඬ⃟👾 _${usedPrefix}zodiac *AAAA MM DD*_
┣ ඬ⃟👾 _${usedPrefix}readmore *texto1| texto2*_
┣ ඬ⃟👾 _${usedPrefix}calc *expresión matemática*_ 
┣ ඬ⃟👾 _${usedPrefix}spamwa *numero|texto|cantidad*_
┣ ඬ⃟👾 _${usedPrefix}readqr *responde a un código QR*_
┣ ඬ⃟👾 _${usedPrefix}anime *random / waifu / husbu /neko*_
┣ ඬ⃟👾 _${usedPrefix}subirestado *texto / responder video, imagen o gif*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 +18༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┃ 𝙇𝘼 𝙋𝘼𝙅𝘼 𝙀𝙎 𝙈𝘼𝙇𝘼 :𝙑 𝙐𝙎𝘼𝙍 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 𝘽𝘼𝙅𝙊 𝙎𝙐 𝙍𝙀𝙎𝙋𝙊𝙉𝙎𝘼𝘽𝙄𝙇𝙄𝘿𝘼𝘿 
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🔞 _${usedPrefix}labiblia_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝙀𝙁𝙀𝘾𝙏𝙊𝙎 𝙋𝘼𝙍𝘼 𝙉𝙊𝙏𝘼𝙎 𝘿𝙀 𝙑𝙊𝙕 𝙊 𝘼𝙐𝘿𝙄𝙊𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┃ 𝙧𝙚𝙨𝙥𝙤𝙣𝙙𝙚 𝙖 𝙪𝙣 𝙖𝙪𝙙𝙞𝙤𝙨 𝙤 𝙣𝙤𝙩𝙖 𝙙𝙚 𝙫𝙤𝙯
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🎤 _${usedPrefix}bass_
┣ ඬ⃟🎤 _${usedPrefix}deep_
┣ ඬ⃟🎤 _${usedPrefix}earrape_
┣ ඬ⃟🎤 _${usedPrefix}fast_
┣ ඬ⃟🎤 _${usedPrefix}fat_
┣ ඬ⃟🎤 _${usedPrefix}nightcore_
┣ ඬ⃟🎤 _${usedPrefix}reverse_
┣ ඬ⃟🎤 _${usedPrefix}robot_
┣ ඬ⃟🎤 _${usedPrefix}slow_
┣ ඬ⃟🎤 _${usedPrefix}smooth_
┣ ඬ⃟🎤 _${usedPrefix}vibracion *cantidad*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃   ༆𝘼𝙐𝘿𝙄𝙊𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🔊 _${usedPrefix}menu2_
┣ ඬ⃟🔊 _${usedPrefix}menuaudios_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝘾𝙃𝘼𝙏 𝘼𝙉𝙊𝙉𝙄𝙈𝙊༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟📳 _${usedPrefix}start_
┣ ඬ⃟📳 _${usedPrefix}next_
┣ ඬ⃟📳 _${usedPrefix}leave_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃  ༆𝘾𝙊𝙉𝙑𝙄𝙀𝙍𝙏𝙀𝙏𝙀 𝙀𝙉 𝘽𝙊𝙏༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟🏷 _${usedPrefix}stop_
┣ ඬ⃟🏷 _${usedPrefix}jadibot_
┣ ඬ⃟🏷 _${usedPrefix}getcode_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃ ༆𝙇𝙊𝙂𝙊𝙎 𝙋𝙀𝙍𝙎𝙊𝙉𝘼𝙇𝙄𝙕𝘼𝘿𝙊𝙎༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟📝️ _${usedPrefix}logos_ (lista)
┣ ඬ⃟📝️ _${usedPrefix}lolice_
┣ ඬ⃟📝️ _${usedPrefix}simpcard_
┣ ඬ⃟📝️ _${usedPrefix}hornycard_ 
┣ ඬ⃟📝️ _${usedPrefix}lblackpink_
┣ ඬ⃟📝️ _${usedPrefix}coffe *texto*_
┣ ඬ⃟📝️ _${usedPrefix}tahta *texto*_
┣ ඬ⃟📝️ _${usedPrefix}nulis *texto*_
┣ ඬ⃟📝️ _${usedPrefix}nulis2 *texto*_
┣ ඬ⃟📝️ _${usedPrefix}lolice *@tag*_
┣ ඬ⃟📝️ _${usedPrefix}simpcard *@tag*_
┣ ඬ⃟📝️ _${usedPrefix}logotaza *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}logocesped *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}logotaza2 *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}flaming *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}logofire *texto*_
┣ ඬ⃟📝️ _${usedPrefix}logosky *texto*_
┣ ඬ⃟📝️ _${usedPrefix}logocorazon *texto*_
┣ ඬ⃟📝️ _${usedPrefix}logorandom *texto*_
┣ ඬ⃟📝️ _${usedPrefix}neonfire *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}technology *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}playa *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}ytcomment *texto*_ 
┣ ඬ⃟📝️ _${usedPrefix}lovemessages *texto*_
┣ ඬ⃟📝️ _${usedPrefix}cementerio *texto*_
┣ ඬ⃟📝️ _${usedPrefix}romanticdouble *texto*_
┣ ඬ⃟📝️ _${usedPrefix}romanticmessages *texto*_
┗━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━┓
┃ ༆𝙋𝙍𝙊𝙋𝙄𝙀𝙏𝘼𝙍𝙄𝙊 𝘿𝙀𝙇 𝘽𝙊𝙏༆
┃≡≡≡≡≡≡≡≡≡≡≡≡≡≡
┣ ඬ⃟👑 _${usedPrefix}boost_
┣ ඬ⃟👑 _${usedPrefix}restart_
┣ ඬ⃟👑 _${usedPrefix}banlist_
┣ ඬ⃟👑 _${usedPrefix}binario1_
┣ ඬ⃟👑 _${usedPrefix}binario2_
┣ ඬ⃟👑 _${usedPrefix}banchat2_
┣ ඬ⃟👑 _${usedPrefix}actualizar_
┣ ඬ⃟👑 _${usedPrefix}CajaFuerte_
┣ ඬ⃟👑 _${usedPrefix}unbanchat2_
┣ ඬ⃟👑 _${usedPrefix}bc *texto*_
┣ ඬ⃟👑 _${usedPrefix}deletechat_
┣ ඬ⃟👑 _${usedPrefix}mutechat_
┣ ඬ⃟👑 _${usedPrefix}bcgc *texto*_
┣ ඬ⃟👑 _${usedPrefix}bcbot *texto*_
┣ ඬ⃟👑 _${usedPrefix}mutechat *all*_
┣ ඬ⃟👑 _${usedPrefix}setbye *@tag*_
┣ ඬ⃟👑 _${usedPrefix}banuser *@tag*_
┣ ඬ⃟👑 _${usedPrefix}deletechat *all*_
┣ ඬ⃟👑 _${usedPrefix}mutechat *chat*_
┣ ඬ⃟👑 _${usedPrefix}mutechat *group*_
┣ ඬ⃟👑 _${usedPrefix}enable *public*_
┣ ඬ⃟👑 _${usedPrefix}disable *public*_
┣ ඬ⃟👑 _${usedPrefix}deletechat *chat*_
┣ ඬ⃟👑 _${usedPrefix}deletechat *group*_
┣ ඬ⃟👑 _${usedPrefix}unbanuser *@tag*_
┣ ඬ⃟👑 _${usedPrefix}listgroup *@tag*_
┣ ඬ⃟👑 _${usedPrefix}enable *restrict*_
┣ ඬ⃟👑 _${usedPrefix}enable *autoread*_
┣ ඬ⃟👑 _${usedPrefix}setwelcome *@tag*_
┣ ඬ⃟👑 _${usedPrefix}enable *autoread*_
┣ ඬ⃟👑 _${usedPrefix}disable *autoread*_
┗━━━━━━━━━━━━━┛`.trim()
let mentionedJid = [who]
conn.send3ButtonImg(m.chat, pp, menu, 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏', '🔥𝙈𝙀𝙉𝙐 𝙎𝙄𝙀𝙈𝙋𝙇𝙀🔥', `🔥#menusimple🔥`, '🔊𝙈𝙀𝙉𝙐 𝘼𝙐𝘿𝙄𝙊𝙎🔊', `🔊#menuaudios🔊`, '✅𝙂𝙍𝙐𝙋𝙊𝙎 𝙊𝙁𝙄𝘾𝙄𝘼𝙇𝙀𝙎✅', `✅#grupos✅`, m, false, { contextInfo: { mentionedJid }})   
//await await await await await await conn.sendFile(m.chat, vn, 'mariana.mp3', null, m, true, {
//type: 'audioMessage', 
//ptt: true 
//})
}
handler.command = /^(menu|menú|memu|memú|help|info|comandos|allmenu|2help|menu1.2|ayuda|commands|commandos)$/i
handler.fail = null
module.exports = handler
