let handler = async (m, { conn, command, text }) => {
  conn.reply(m.chat, `
😍❤️🥺𝙈𝙚𝙙𝙞𝙙𝙤𝙧 𝙙𝙚 𝙖𝙢𝙤𝙧🥺❤️😍

𝙀𝙡 𝙖𝙢𝙤𝙧 𝙙𝙚 ${text} 𝙥𝙤𝙧 𝙩𝙞 𝙚𝙨 𝙙𝙚 ${Math.floor(Math.random()  100)}% 𝙙𝙚 𝙪𝙣 100%
¡¡¡𝙙𝙚𝙗𝙚𝙧𝙞𝙖𝙨 𝙦𝙪𝙚 𝙥𝙚𝙙𝙞𝙧𝙡𝙚 𝙦𝙪𝙚 𝙨𝙚𝙖 𝙩𝙪 𝙣𝙤𝙫𝙞𝙖/𝙤 𝙘𝙤𝙧𝙧𝙚 𝙮 𝙙𝙞𝙡𝙚 𝙣𝙤 𝙨𝙚𝙖𝙨 𝙥𝙚𝙣𝙙𝙚𝙟@!!!
`.trim(), m, m.mentionedJid ? {
    contextInfo: {
      mentionedJid: m.mentionedJid
    }
  } : {})
}
handler.command = /^(love)/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
