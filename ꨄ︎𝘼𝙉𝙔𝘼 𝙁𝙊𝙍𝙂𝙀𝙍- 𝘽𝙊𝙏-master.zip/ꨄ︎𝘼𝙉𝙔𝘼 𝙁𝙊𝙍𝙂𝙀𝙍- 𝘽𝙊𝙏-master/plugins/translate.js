const translate = require('translate-google-api')
const defaultLang = 'es'
const tld = 'cn'
let handler = async (m, { args, usedPrefix, command }) => {
let msg = `[❗] 𝙐𝙎𝙊 𝘾𝙊𝙍𝙍𝙀𝘾𝙏𝙊 𝘿𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 ${usedPrefix + command} (𝙄𝘿𝙄𝙊𝙈𝘼) (𝙏𝙀𝙓𝙏𝙊)\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊:\nꨄ︎${usedPrefix + command} 𝙀𝙎 𝙃𝙀𝙇𝙇𝙊\n\n𝘾𝙊𝙉𝙊𝘾𝙀 𝙇𝙊𝙎 𝙄𝘿𝙄𝙊𝙈𝘼𝙎 𝘼𝘿𝙈𝙄𝙏𝙄𝘿𝙊𝙎𝘼𝙌𝙐𝙄\nꨄ︎- https://cloud.google.com/translate/docs/languagesꨄ︎.`
if (!args || !args[0]) return m.reply(msg)
let lang = args[0]
let text = args.slice(1).join(' ')
if ((args[0] || '').length !== 2) {
lang = defaultLang
text = args.join(' ') }
if (!text && m.quoted && m.quoted.text) text = m.quoted.text
let result
try {
result = await translate(`${text}`, {
tld,
to: lang, })
} catch (e) {
result = await translate(`${text}`, {
tld,
to: defaultLang, })
} finally {
m.reply('𝙏𝙍𝘼𝘿𝙐𝘾𝘾𝙄𝙊𝙉 ' +  result[0]) }}
handler.command = /^(tr(anslate)|traducir?)$/i
handler.fail = null
module.exports = handler
