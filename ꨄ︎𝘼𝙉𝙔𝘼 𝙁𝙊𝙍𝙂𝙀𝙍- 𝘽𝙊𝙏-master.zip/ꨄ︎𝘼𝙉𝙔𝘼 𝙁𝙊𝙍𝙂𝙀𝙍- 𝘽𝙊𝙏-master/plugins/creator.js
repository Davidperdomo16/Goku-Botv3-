function handler(m) {
this.sendContact(m.chat, global.owner[0], this.getName(global.owner[0] + '@s.whatsapp.net'), m)
this.sendContact(m.chat, '50497501147', '𝙎𝙊𝙁𝙄𝘼 - 𝘾𝙍𝙀𝘼𝘿𝙊𝙍 - 𝙊𝙁𝙄𝘾𝙄𝘼𝙇 1', m)
this.sendContact(m.chat, '50495086382', '𝙎𝙊𝙁𝙄𝘼 - 𝘾𝙍𝙀𝘼𝘿𝙊𝙍 - 𝙊𝙁𝙄𝘾𝙄𝘼𝙇 2', m)}
handler.command = /^(contacto|owner|creator|creador|propietario|dueño)$/i
module.exports = handler
