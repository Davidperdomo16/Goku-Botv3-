let handler = async (m, { conn, participants }) => {
// if (participants.map(v=>v.jid).includes(global.conn.user.jid)) {
if (!(m.chat in global.DATABASE._data.chats)) return m.reply('⚠️▶𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝙉𝙊 𝙀𝙎𝙏 𝙍𝙀𝙂𝙄𝙎𝙏𝙍𝘼𝘿𝙊 𝙀𝙇 𝘽𝘼𝙎𝙀 𝘿𝙀 𝘿𝘼𝙏𝙊𝙎⚠️')
let chat = global.DATABASE._data.chats[m.chat]
if (chat.isBanned) return m.reply('⚠️ 𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝙔𝘼 𝙀𝙎𝙏𝘼𝘽𝘼 𝘽𝘼𝙉𝙀𝘼𝘿𝙊 ⚠️\n 😉☃ 𝙎𝙄 𝘿𝙀𝙎𝙀𝘼 𝘿𝙀𝙎𝘽𝘼𝙉𝙀𝘼𝙍𝙇𝙊 𝙐𝙎𝙀 /𝙐𝙉𝘽𝘼𝙉𝘾𝙃𝘼𝙏 😉')
chat.isBanned = true
m.reply(' ✅ 𝙀𝙎𝙏𝙀 𝘾𝙃𝘼𝙏 𝘼 𝙎𝙄𝘿𝙊 𝘽𝘼𝙉𝙀𝘼𝘿𝙊 𝙀𝙓𝙄𝙏𝙊𝙓𝘼𝙈𝙀𝙉𝙏𝙀 ✅')
// } else m.reply('Aquí hay un número de un host...')
}
handler.command = /^banchat$/i
handler.group = true
handler.admin = true
module.exports = handler
