let R = Math.random
let Fl = Math.floor
let toM = a => '@' + a.split('@')[0]
function handler(m, { groupMetadata }) {
    let ps = groupMetadata.participants.map(v => v.jid)
    let a = ps[Fl(R() * ps.length)]
    let b
    do b = ps[Fl(R() * ps.length)]
    while (b === a)
    let c
    do c = ps[Fl(R() * ps.length)]
    while (b === a)
    m.reply(`𝙃𝙀𝙔!!! ${toM(a)}, ${toM(b)} 𝙔 ${toM(c)} 𝙋𝙊𝙍 𝙌𝙐𝙀 𝙉𝙊 𝙃𝘼𝘾𝙀𝙉 𝙐𝙉 𝙏𝙍𝙄𝙊 𝙋𝘼𝙅𝙀𝙍@𝙎? 𝙐𝙎𝙏𝙀𝘿𝙀𝙎 3 𝙃𝘼𝘾𝙀𝙉 𝙐𝙉 𝙀𝙓𝙀𝙇𝙀𝙉𝙏𝙀 𝙏𝙍𝙄𝙊 😏🔥`, null, {
        contextInfo: {
            mentionedJid: [a, b, c],
        }
    })
}
handler.help = ['formartrio']
handler.tags = ['General']
handler.command = ['formartrio','formartrios']
handler.group = true

module.exports = handler
