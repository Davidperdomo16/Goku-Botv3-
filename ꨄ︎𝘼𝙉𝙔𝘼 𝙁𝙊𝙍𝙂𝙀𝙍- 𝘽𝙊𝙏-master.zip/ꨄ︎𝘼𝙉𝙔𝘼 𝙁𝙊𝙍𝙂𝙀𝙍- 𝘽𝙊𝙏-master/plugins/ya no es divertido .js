let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/ya no es divertido.mp3'
conn.sendFile(m.chat, vn, 'ya no es divertido.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /ya no es divertido|YA NO ES DIVERTIDO|trizte/
handler.command = /^(ya no es divertido|trizte|YA NO ES DIVERTIDO?$)/

module.exports = handler