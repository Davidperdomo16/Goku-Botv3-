let handler  = async (m, { conn }) => {
  if (global.conn.user.jid == conn.user.jid) conn.reply(m.chat, '𝙋𝙊𝙍 𝙌𝙐𝙀 𝙉𝙊 𝙑𝘼𝙎 𝘿𝙄𝙍𝙀𝘾𝙏𝘼𝙈𝙀𝙉𝙏𝙀 𝘾𝙊𝙉 𝙀𝙇 𝙉𝙐𝙈𝙀𝙍𝙊 𝘿𝙀𝙇 𝘽𝙊𝙏?', m)
  else {
    await conn.reply(m.chat, '𝘼𝘿𝙄𝙊𝙎 𝘽𝙊𝙏 :\')', m)
    conn.close()
  }
}
handler.help = ['berhenti','stop']
handler.tags = ['General']
handler.command = /^(berhenti|stop)$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

