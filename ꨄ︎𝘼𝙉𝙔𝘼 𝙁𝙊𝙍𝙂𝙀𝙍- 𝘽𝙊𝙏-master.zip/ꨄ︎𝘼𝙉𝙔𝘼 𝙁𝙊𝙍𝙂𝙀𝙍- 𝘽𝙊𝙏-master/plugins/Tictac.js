const TicTacToe = require("../lib/tictactoe")

let handler = async (m, { conn, usedPrefix, command, text }) => {
    conn.game = conn.game ? conn.game : {}
    if (Object.values(conn.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw '⚠️ 𝘼𝙐𝙉 𝙀𝙎𝙏𝘼𝙎 𝙀𝙉 𝙐𝙉𝘼 𝙎𝘼𝙇𝘼 𝘿𝙀 𝙅𝙐𝙀𝙂𝙊\n\n👉🏻 𝙋𝘼𝙍𝘼 𝙎𝘼𝙇𝙄𝙍 𝙀𝙎𝘾𝙍𝙄𝘽𝙀 "𝙎𝘼𝙇𝙄𝙍" 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝙄𝙀𝙉𝘿𝙊 𝙀𝙇 𝙈𝙀𝙉𝙎𝘼𝙅𝙀 𝘿𝙀𝙇 𝙄𝙉𝙄𝘾𝙄𝙊 𝙌𝙐𝙀 𝙀𝙉𝙑𝙄𝙊 𝙀𝙇 𝘽𝙊𝙏\n\n𝙏𝘼𝙈𝘽𝙄𝙀𝙉 𝙋𝙐𝙀𝘿𝙀𝙎 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝙍 𝙇𝘼 𝙎𝘼𝙇𝘼 𝙀𝙎𝘾𝙍𝙄𝘽𝙄𝙀𝙉𝘿𝙊: #𝘿𝙀𝙇𝙏𝙏𝙏 -𝙉𝙊𝙈𝘽𝙍𝙀 𝘿𝙀 𝙇𝘼 𝙎𝘼𝙇𝘼-'
    let room = Object.values(conn.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
    // m.reply('[WIP Feature]')
    if (room) {
        m.reply('✅ 𝙐𝙉 𝙅𝙐𝙂𝘼𝘿𝙊𝙍 𝙄𝙉𝙂𝙍𝙀𝙎𝙊 𝘼 𝙇𝘼 𝙎𝘼𝙇𝘼')
        room.o = m.chat
        room.game.playerO = m.sender
        room.state = 'PLAYING'
        let arr = room.game.render().map(v => {
            return {
                X: '❌',
                O: '⭕',
                1: '1️⃣',
                2: '2️⃣',
                3: '3️⃣',
                4: '4️⃣',
                5: '5️⃣',
                6: '6️⃣',
                7: '7️⃣',
                8: '8️⃣',
                9: '9️⃣',
            }[v]
        })
        let str = `
𝘾𝙇𝘼𝙎𝙄𝘾𝙊 𝘿𝙀 𝙂𝘼𝙏𝙊 𝙊 3 𝙀𝙉 𝙍𝘼𝙔𝘼
¿𝘾𝙊𝙈𝙊 𝙅𝙐𝙂𝘼𝙍? 𝙍= _𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼𝙇 𝙈𝙀𝙉𝙎𝘼𝙅𝙀 𝙌𝙐𝙀 𝙀𝙉𝙑𝙄𝙀 𝙀𝙇 𝘽𝙊𝙏 𝘾𝙊𝙉 𝙇𝘼 𝙏𝘼𝘽𝙇𝙄𝙏𝘼 𝘿𝙀𝙇 𝙅𝙐𝙍𝙂𝙊, 𝙀𝙇 𝙈𝙀𝙉𝙎𝘼𝙅𝙀 𝘿𝙀𝘽𝙀 𝘾𝙊𝙉𝙏𝙀𝙉𝙀𝙍 𝙇𝘼 𝙋𝙊𝙎𝙄𝘾𝙄𝙊𝙉  𝙀𝙉 𝙇𝘼 𝙌𝙐𝙀 𝙌𝙐𝙄𝙀𝙍𝘼𝙎 𝙀𝙎𝙏𝘼𝙍 (1,2,3,4,5,6,7,8,9)_

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

𝙀𝙎 𝙏𝙐𝙍𝙉𝙊 𝘿𝙀 @${room.game.currentTurn.split('@')[0]}*
𝙋𝘼𝙍𝘼 𝙍𝙀𝙉𝘿𝙄𝙍𝙎𝙀 𝙋𝙐𝙀𝘿𝙀 𝙐𝙏𝙄𝙇𝙄𝙕𝘼𝙍 "𝙎𝘼𝙇𝙄𝙍", 𝙉𝙊 𝙀𝙎𝘾𝙍𝙄𝘽𝘼 𝙉𝙄𝙉𝙂𝙐𝙉𝘼 𝙋𝙍𝙀𝙁𝙄𝙅𝙊 " 𝙉𝙄 𝙇𝘼𝙎 𝙔 𝙀𝙇 𝙈𝙀𝙉𝙎𝘼𝙅𝙀 𝘿𝙀𝘽𝙀 𝙎𝙀𝙍 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝙄𝘿𝙊 𝘼𝙇 𝙈𝙀𝙉𝙎𝘼𝙅𝙀 𝘿𝙀𝙇 𝙅𝙐𝙀𝙂𝙊 𝙀𝙉 𝘿𝙊𝙉𝘿𝙀 𝙎𝘼𝙇𝙂𝘼 𝙇𝘼 𝙏𝘼𝘽𝙇𝘼 𝘿𝙀 𝙅𝙐𝙍𝙂𝙊 
`.trim()
        if (room.x !== room.o) m.reply(str, room.x, {
            contextInfo: {
                mentionedJid: conn.parseMention(str)
            }
        })
        m.reply(str, room.o, {
            contextInfo: {
                mentionedJid: conn.parseMention(str)
            }
        })
    } else {
        room = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
        }
        if (text) room.name = text
        m.reply('🥱 𝙀𝙎𝙋𝙀𝙍𝘼𝙉𝘿𝙊 𝘼 𝙌𝙐𝙀 𝙀𝙇 𝙅𝙐𝙂𝘼𝘿𝙊𝙍 2 𝙎𝙀 𝙐𝙉𝘼𝙇𝘼 𝙎𝘼𝙇𝘼 ' + (text ? `𝙀𝙇 𝙅𝙐𝙂𝘼𝘿𝙊𝙍 2 𝘿𝙀𝘽𝙀 𝙀𝙎𝘾𝙍𝙄𝘽𝙄𝙍 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 𝘼 𝘾𝙊𝙉𝙏𝙄𝙉𝙐𝘼𝘾𝙄𝙊𝙉 r𝙍𝙀𝙎𝙋𝙀𝙏𝘼𝙉𝘿𝙊 𝙇𝘼𝙎 𝙈𝘼𝙔𝙐𝙎𝘾𝙐𝙇𝘼𝙎, 𝙋𝙐𝙉𝙏𝙊𝙎 𝙔 𝘼𝘾𝙀𝙉𝙏𝙐𝘼𝘾𝙄𝙊𝙉𝙀𝙎:
${usedPrefix}${command} ${text}` : ''))
        conn.game[room.id] = room
    }
}

handler.help = ['tictactoe', 'ttt'].map(v => v + ' [custom room name]')
handler.tags = ['']
handler.command = /^(tictactoe|t{3})$/

module.exports = handler