let handler = async (m, { conn, command, text }) => {
  if (!text) throw `𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙚𝙡 @ 𝙤 𝙚𝙡 𝙣𝙤𝙢𝙗𝙧𝙚 𝙙𝙚 𝙡𝙖 𝙥𝙚𝙧𝙨𝙤𝙣𝙖 𝙦𝙪𝙚 𝙙𝙚𝙨𝙚𝙚 𝙘𝙖𝙡𝙘𝙪𝙡𝙖𝙧 𝙨𝙪 𝙥𝙤𝙧𝙘𝙚𝙣𝙩𝙖𝙟𝙚 𝙙𝙚 ${command.replace('how', '')}`
  conn.reply(m.chat, `
_${text} 𝙚𝙨 🥵💦 ${Math.floor(Math.random() 
 1039193829)}% ${command.replace('how', '').toUpperCase()}*_
`.trim(), m, m.mentionedJid ? {
    contextInfo: {
      mentionedJid: m.mentionedJid
    }
  } : {})
}
handler.help = ['𝙜𝙖𝙮', '𝙡𝙚𝙨𝙗𝙞'].map(v => 'how' + v + ' siapa?')
handler.tags = ['kerang']
handler.command = /^(pajero|pajera)/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
