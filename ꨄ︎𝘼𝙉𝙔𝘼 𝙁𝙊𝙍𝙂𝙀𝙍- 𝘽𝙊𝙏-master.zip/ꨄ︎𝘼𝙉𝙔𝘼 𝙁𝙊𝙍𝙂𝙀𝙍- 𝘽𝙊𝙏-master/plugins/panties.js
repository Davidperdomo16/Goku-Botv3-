let axios = require("axios")
let handler = async (m, { conn, usedPrefix, command }) => {
if (!DATABASE._data.chats[m.chat].nsfw && m.isGroup) throw '*[ ⚠️ ] Los comandos +18 estan desactivados en este grupo, si es administrador de este grupo y desea activarlos escriba #enable nsfw*'
let res = await axios("https://meme-api.herokuapp.com/gimme/panties")
let json = res.data
let url = json.url
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
conn.send2ButtonImg(m.chat, url, "🔥 𝙥𝙖𝙣𝙩𝙞𝙚𝙨 🔥", 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏', '🥵 𝙨𝙞𝙜𝙪𝙞𝙚𝙣𝙩𝙚 🥵', `${usedPrefix + command}`, '🔥 𝙇𝘼𝘽𝙄𝘽𝙇𝙄𝘼 🔥', `${usedPrefix}labiblia`, m, false, { contextInfo: { mentionedJid }}) }
handler.command = /^(panties)$/i
module.exports = handler
