const uploadImage = require('../lib/uploadImage') 
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn, text }) => {
 try {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼 𝙐𝙉𝘼 𝙁𝙊𝙏𝙊'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `𝙏𝘼𝙈𝘼𝙉̃𝙊 𝙉𝙊 𝙎𝙊𝙋𝙊𝙍𝙏𝘼𝘿𝙊`
  let img = await q.download()
  let url = await uploadImage(img)
  let wanted = global.API('dzx', '/api/canvas/trash', { url }) //`https://api.dhamzxploit.my.id/api/canvas/trash?url=${url}`
  let stiker = await sticker(null, wanted, 'trash', 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏')
  conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
 } catch (e) {
   m.reply('Conversion Failed')
  }
}
handler.help = ['trash']
handler.tags = ['General']
handler.command = /^trash$/i

module.exports = handler
