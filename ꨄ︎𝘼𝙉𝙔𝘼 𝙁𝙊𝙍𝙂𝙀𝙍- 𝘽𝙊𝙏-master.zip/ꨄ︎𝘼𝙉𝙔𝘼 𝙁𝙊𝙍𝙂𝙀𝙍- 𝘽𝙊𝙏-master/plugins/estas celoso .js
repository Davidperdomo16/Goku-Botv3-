let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/estas celoso.mp3'
conn.sendFile(m.chat, vn, 'estas celoso.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /estas celoso|ESTAS CELOSO|Estas celoso/
handler.command = /^(celoso|ESTAS CELOSO|estas celoso|CELOSO?$)/

module.exports = handler