//by nobuyaki
//jangan hapus hargai yang bikin
//remake by dhamz

const uploadImage = require('../lib/uploadImage') 
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn, text }) => {
 try {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '𝙄𝙈𝘼𝙂𝙀𝙉 𝙉𝙊 𝙎𝙊𝙋𝙊𝙍𝙏𝘼𝘿𝘼'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `𝙀𝙇 𝙋𝙀𝙎𝙊 ${mime} 𝙉𝙊 𝙎𝙊𝙋𝙊𝙍𝙏𝘼𝘿𝙊`
  let img = await q.download()
  let url = await uploadImage(img)
  let wasted = `https://some-random-api.ml/canvas/wasted?avatar=${url}`
  let stiker = await sticker(null, wasted, 'Wasted', 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍- 𝘽𝙊𝙏')
  conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
 } catch (e) {
   m.reply('𝘾𝙊𝙉𝙑𝙀𝙍𝙎𝙄𝙊𝙉 𝙁𝘼𝙇𝙇𝙄𝘿𝘼, 𝙍𝙀𝘾𝙐𝙀𝙍𝘿𝙀 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝙀𝙍 𝙐𝙉𝘼 𝙄𝙈𝘼𝙂𝙀𝙉')
  }
}
handler.help = ['wasted']
handler.tags = ['General']
handler.command = /^wasted$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
