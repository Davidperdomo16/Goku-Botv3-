let handler = m => m

let linkRegex = /https:/i
handler.before = async function (m, { user, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true
  let chat = global.DATABASE.data.chats[m.chat]
  let isGroupLink = linkRegex.exec(m.text)

  if (chat.antiLink2 && isGroupLink) {
    await m.reply(`『 𝘼𝙉𝙏𝙄 𝙇𝙄𝙉𝙆𝙎 』\n𝙃𝘼𝙎𝙏𝘼 𝙇𝘼 𝙑𝙄𝙎𝙏𝘼 𝙈𝘼𝙅𝙀😂, ${await this.getName(m.sender)} ⚠️𝙍𝙊𝙈𝙋𝙄𝙎𝙏𝙀 𝙇𝘼𝙎 𝙍𝙀𝙂𝙇𝘼𝙎 𝙎𝙀𝙍𝘼𝙎 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝘿@ 𝘿𝙀𝙇 𝙂𝙍𝙐𝙋𝙊....!!⚠️`)
    await m.reply(`⚠️𝙏𝙄𝙀𝙉𝙀𝙎 3 𝙎𝙀𝙂𝙐𝙉𝘿𝙊𝙎 𝙋𝘼𝙍𝘼 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝙍 𝙀𝙇 𝙋𝙐𝙏𝙊 𝙇𝙄𝙉𝙆⚠️...!!!!`)
    await m.reply(`3!!`)
    await m.reply(`2!!`)
    await m.reply(`1!!`)
    if (isAdmin) return m.reply('𝙏𝙀 𝙎𝘼𝙇𝙑𝘼𝙎𝙏𝙀 𝙋𝙀𝙉𝘿𝙀𝙅𝙊 (𝘼) 𝙀𝙍𝙀𝙎 𝘼𝘿𝙈𝙄𝙉, 𝙉𝙊 𝙋𝙐𝙀𝘿𝙊 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝙍𝙏𝙀 𝙓𝘿 :v')
    if (!isBotAdmin) return m.reply('😔𝙉𝙊 𝙎𝙊𝙔 𝘼𝘿𝙈𝙄𝙉, 𝙉𝙊 𝙋𝙐𝙀𝘿𝙊 𝙀𝙇𝙄𝙈𝙄𝙉𝘼𝙍 𝙋𝙀𝙍𝙎𝙊𝙉𝘼𝙎😔')
    let linkGC = ('https://chat.whatsapp.com/' + await this.groupInviteCode(m.chat))
    let isLinkThisGc = new RegExp(linkGC, 'i')
    let isgclink = isLinkThisGc.test(m.text)
    if (isgclink) return m.reply('𝙓𝘿.. 𝙀𝙉𝙑𝙄𝘼𝙎𝙏𝙀 𝙀𝙇 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙀𝙎𝙏𝙀 𝙂𝙍𝙐𝙋𝙊 :v')
    await this.groupRemove(m.chat, [m.sender])
  }
  return true
}

module.exports = handler
