let fetch = require('node-fetch')
let handler = async (m, { text, usedPrefix, command, args }) => {
let msg = `[⚠️] 𝘂𝘀𝗼 𝗰𝗼𝗿𝗿𝗲𝗰𝘁𝗼 𝗱𝗲𝗹 𝗰𝗼𝗺𝗮𝗻𝗱𝗼 ${usedPrefix + command} (𝗮𝘂𝘁𝗼𝗿) (𝗰𝗮𝗻𝗰𝗶𝗼𝗻)\n𝗘𝗷𝗲𝗺𝗽𝗹𝗼\n${usedPrefix + command} 𝙗𝙖𝙙𝙗𝙪𝙣𝙮 𝙩𝙞𝙩𝙞 𝙢𝙚 𝙥𝙧𝙚𝙜𝙪𝙣𝙩𝙤*`
if (!args || !args[0]) return m.reply(msg)
try {
let res = await fetch(global.API('https://some-random-api.ml', '/lyrics', {
title: text}))
if (!res.ok) throw await res.text()
let json = await res.json()
if (!json.thumbnail.genius) throw json
let teks = `*${json.title}*\n_${json.author}_\n\n${json.lyrics}\n\n\n${json.links.genius}`
let foot = 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏'
conn.send2ButtonImg(m.chat, await(await fetch(json.thumbnail.genius)).buffer(), teks, foot,'🎧 𝘿𝙚𝙨𝙘𝙖𝙧𝙜𝙖𝙧 𝙢𝙪𝙨𝙞𝙘𝙖 🔊', `#play ${text}`, '🎥 𝘿𝙚𝙨𝙘𝙖𝙧𝙜𝙖𝙧 𝙫𝙞𝙙𝙚𝙤 🎞️', `#play2 ${text}`, m)
} catch (e) {
console.log(e)
m.reply('[⚠️] 𝙣𝙤 𝙨𝙚 𝙚𝙣𝙘𝙤𝙣𝙩𝙧𝙤 𝙡𝙖 𝙡𝙚𝙩𝙧𝙖 𝙙𝙚 𝙡𝙖 𝙘𝙖𝙣𝙘𝙞𝙤𝙣, 𝙥𝙤𝙧 𝙛𝙖𝙫𝙤𝙧 𝙥𝙧𝙪𝙚𝙗𝙖 𝙘𝙤𝙣 𝙤𝙩𝙧𝙖')}}
handler.command = /^(l(irik|yrics)|letra)$/i
module.exports = handler
