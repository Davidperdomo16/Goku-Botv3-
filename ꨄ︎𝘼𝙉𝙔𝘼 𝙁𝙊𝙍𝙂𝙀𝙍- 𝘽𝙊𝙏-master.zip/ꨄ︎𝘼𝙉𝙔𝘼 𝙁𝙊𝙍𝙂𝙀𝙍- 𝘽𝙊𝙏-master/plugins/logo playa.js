let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
response = args.join(' ').split('|')
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤\n𝙚𝙟𝙚𝙢𝙥𝙡𝙤:)\n*#𝙥𝙡𝙖𝙮𝙖 𝙖𝙣𝙮𝙖'        
let res = `https://api-alc.herokuapp.com/api/textpro/on-the-beach?texto=${response[0]}&apikey=ConfuMods`
conn.sendFile(m.chat, res, 'error.jpg', `*Logo terminado*`, m, false)}
handler.command = /^(logoplaya|playa)$/i
module.exports = handler
