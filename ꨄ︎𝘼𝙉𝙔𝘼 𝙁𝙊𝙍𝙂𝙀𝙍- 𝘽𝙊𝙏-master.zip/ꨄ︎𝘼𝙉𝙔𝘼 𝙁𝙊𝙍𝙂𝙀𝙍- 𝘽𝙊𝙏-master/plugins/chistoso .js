let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/chistoso.mp3'
conn.sendFile(m.chat, vn, 'chistoso.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /chistoso|CHISTOSO|Chistoso/
handler.command = /^(chistoso|CHISTODO|COMICO|comico|chistosa|CHISTOSA?$)/

module.exports = handler