//Agradecimientos a GataNina-Li "https://github.com/GataNina-Li"
let axios = require("axios")
let fetch = require("node-fetch")
let cheerio = require("cheerio")
async function wikipedia(querry) {
try {
const link = await axios.get(`https://es.wikipedia.org/wiki/${querry}`)
const $ = cheerio.load(link.data)
let judul = $('#firstHeading').text().trim()
let thumb = $('#mw-content-text').find('div.mw-parser-output > div:nth-child(1) > table > tbody > tr:nth-child(2) > td > a > img').attr('src') || `//i.ibb.co/nzqPBpC/http-error-404-not-found.png`
let isi = []
$('#mw-content-text > div.mw-parser-output').each(function (rayy, Ra) {
let penjelasan = $(Ra).find('p').text().trim() 
isi.push(penjelasan)})
for (let i of isi) {
const data = {
status: link.status,
result: {
judul: judul,
thumb: 'https:' + thumb,
isi: i}}
return data}
} catch (err) {
var notFond = {
status: link.status,
Pesan: eror}
return notFond}}
let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw `[⚠️️] 𝙀𝙎𝙏𝘼𝙎 𝙐𝙎𝘼𝙉𝘿𝙊 𝙈𝘼𝙇 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊\n𝙐𝙎𝙊 𝘾𝙊𝙍𝙍𝙀𝘾𝙏𝙊\nꨄ︎${usedPrefix + command}  𝙋𝘼𝙇𝘼𝘽𝙍𝘼 𝘾𝙇𝘼𝙑𝙀 𝘼 𝘽𝙐𝙎𝘾𝘼𝙍\n\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊\nꨄ︎${usedPrefix + command} 𝙀𝙎𝙏𝙍𝙀𝙇𝙇𝘼𝙎`
wikipedia(`${text}`).then(res => {
m.reply(`𝘼𝙌𝙐𝙄 𝙏𝙄𝙀𝙉𝙀 𝙇𝘼 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝘾𝙄𝙊𝙉 𝙀𝙉𝘾𝙊𝙉𝙏𝙍𝘼𝘿𝘼 𝘽𝘽🥰\n\n` + res.result.isi)
}).catch(() => { m.reply('[⚠️️] 𝙄𝙉𝙁𝙊𝙍𝙈𝘼𝘾𝙄𝙊𝙉 𝙉𝙊 𝙀𝙉𝘾𝙊𝙉𝙏𝙍𝘼𝘿𝘼, 𝘾𝙊𝙈𝙋𝙍𝙐𝙀𝘽𝘼 𝙌𝙐𝙀 𝙇𝙊 𝙃𝘼𝙔𝘼 𝙀𝙎𝘾𝙍𝙄𝙏𝙊 𝘽𝙄𝙀𝙉 𝙔 𝙌𝙐𝙀 𝙎𝙊𝙇𝙊 𝙎𝙀𝘼 𝙐𝙉𝘼 𝙋𝘼𝙇𝘼𝘽𝙍𝘼') })}
handler.command = /^(wiki|wikipedia|internet?)$/i
module.exports = handler
