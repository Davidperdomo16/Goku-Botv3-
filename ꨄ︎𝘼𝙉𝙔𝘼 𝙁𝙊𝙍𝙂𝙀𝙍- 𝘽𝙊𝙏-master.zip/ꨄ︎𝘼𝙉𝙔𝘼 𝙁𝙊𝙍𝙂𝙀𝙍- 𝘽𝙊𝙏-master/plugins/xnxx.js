let fetch = require("node-fetch");

let axios = require("axios");

let handler = async (m, { conn, args, usedPrefix, command }) => {

  if (!args[0]) throw `[❗] 𝙄𝙉𝙂𝙍𝙀𝙎𝙀 𝙐𝙉 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙇𝘼 𝙋𝘼𝙂𝙄𝙉𝘼 https://xnxx.com\n\n𝙋𝙐𝙀𝘿𝙀 𝙐𝙎𝘼𝙍 𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊: #𝙓𝙉𝙓𝙓𝙎𝙀𝘼𝙍𝙎𝙃 + 𝙏𝙀𝙓𝙏𝙊, 𝙋𝘼𝙍𝘼 𝘽𝙐𝙎𝘾𝘼𝙍 𝙀𝙇 𝙑𝙄𝘿𝙀𝙊 𝙎𝙊𝘽𝙍𝙀 𝙀𝙇 𝙏𝙀𝙓𝙏𝙊`;

conn.reply(m.chat, `
[❗] 𝘼𝙂𝙐𝘼𝙍𝘿𝙀 𝙐𝙉 𝙈𝙊𝙈𝙀𝙉𝙏𝙊..

✅ 𝙀𝙎𝙏𝙊𝙔 𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝙉𝘿𝙊 𝙎𝙐 𝙑𝙄𝘿𝙀𝙊, 𝙀𝙎𝙏𝙊 𝙋𝙐𝙀𝘿𝙀 𝘿𝙀𝙈𝙊𝙍𝘼𝙍 𝘿𝙀 5 𝘼 10 𝙈𝙄𝙉𝙐𝙏𝙊𝙎, 𝙋𝙊𝙍𝙁𝘼𝘽𝙊𝙍 𝙎𝙀𝘼 𝙋𝘼𝘾𝙄𝙀𝙉𝙏𝙀
`.trim(), m);

  let vidurl = args[0].replace("xnxx", "onlineonlineoxnn");

  let res = axios

    .get(

      API("https://www.online-downloader.com", "/DL/YT.php", {

        videourl: vidurl,

        mstr: "9773",

        _: "1633710434836",

      })

    )

    .then((res) => {

      if (res.status != 200) throw `${res.status} ${res.statusText}`;

      let data = JSON.parse(res.data.replace(/[()]/g, ""));

      conn.sendFile(m.chat, data.Video_6_Url, "Error.mp4", "𝘼𝙌𝙐𝙄 𝙏𝙄𝙀𝙉𝙀 𝙎𝙐 𝙑𝙄𝘿𝙀𝙊 𝘼𝙈𝙊𝙍 😏🔥", m);

    });

};

handler.help = ["xnxx"].map((v) => v + " <Link>");

handler.tags = ["nsfw"];

handler.command = /^(xnxx)$/i;

handler.limit = false;

handler.nsfw = false

module.exports = handler;
