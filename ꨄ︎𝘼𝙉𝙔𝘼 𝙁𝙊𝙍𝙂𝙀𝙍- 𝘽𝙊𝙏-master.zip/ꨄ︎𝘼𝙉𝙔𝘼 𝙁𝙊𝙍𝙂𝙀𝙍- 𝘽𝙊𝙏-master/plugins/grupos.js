let { MessageType } = require('@adiwajshing/baileys')
let fs = require('fs')
let handler  = async (m, { conn, usedPrefix: _p }) => {
  
let info = `
*Hola bb ❤️, unete a los grupos oficiales para pasar un rato agradable usando el Bot o platicando con la familia de ꨄ︎ANYA FORGER - BOT*

*➤ Grupos oficiales del Bot:*
*1.-* https://chat.whatsapp.com/HPansN34Tw1JACTIo9vvXd

*2.-* https://chat.whatsapp.com/Hg4gaweGgDIHm11KvUvfgf

*3.-* https://chat.whatsapp.com/FF55w6s9XfYIogIYrK5WWW

*4.-* https://chat.whatsapp.com/IGvEfaxBQvs9FqjmPChfpA
`.trim() 

conn.sendMessage(m.chat, info, MessageType.text, { quoted: { key: { remoteJid: 'status@broadcast', participant: '0@s.whatsapp.net', fromMe: false }, message: { "imageMessage": { "mimetype": "image/jpeg", "caption": '🖤ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏 🖤', "jpegThumbnail": fs.readFileSync(`./Menu2.jpg`)}}}})}

handler.command = /^(grupos|gruposofc|gruposofc)$/i
module.exports = handler
