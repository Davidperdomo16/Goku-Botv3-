process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
let fetch = require('node-fetch')
const { servers, yt } = require('../lib/y2mate')

let handler = async (m, { conn, args, isPrems, isOwner }) => {
let fs = require('fs')
let y = fs.readFileSync('./Menu2.jpg')
  if (!args || !args[0]) throw '[⚠️] 𝙄𝙉𝙎𝙀𝙍𝙏𝙀 𝙀𝙇 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙔𝙊𝙐𝙏𝙐𝘽𝙀\n\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊\n#𝙔𝙏mp4 https://www.youtube.com/watch?v=8jvDzEIVpjg*'
  let chat = global.DATABASE.data.chats[m.chat]
  let quality = args[1] || '360'
  let server = (args[2] || servers[0]).toLowerCase()
  let { dl_link, thumb, title, filesize, filesizeF } = await yt(args[0], quality + 'p', 'mp4', quality, servers.includes(server) ? server : servers[0])
  //let isLimit = (isPrems || isOwner ? 99 : limit) * 99888898 < filesize
let _thumb = {}
  try { _thumb = { thumbnail: await (await fetch(thumb)).buffer() } }
  catch (e) { }
  conn.sendMessage(m.chat, `⏯ ️𝘿𝙀𝘿𝘾𝘼𝙍𝙂𝘼𝙍 𝘽𝙔 𝘼𝙉𝙔𝘼𝘽𝙊𝙏⏯️\n\n𝙏𝙐𝙏𝙄𝙇𝙊🔥 ${title}\n🗂️𝙏𝘼𝙈𝘼𝙉̃𝙊 𝘿𝙀𝙇 𝘼𝙍𝘾𝙃𝙄𝙑𝙊 ${filesizeF}` , '𝘾𝙊𝙉𝙑𝙀𝙍𝙎𝘼𝙏𝙄𝙊𝙉', {quoted: m, thumbnail: y, contextInfo:{externalAdReply: {title: '𝙎𝙄𝙈𝙋𝙇𝙀 𝙒𝙃𝘼𝙏𝙎𝘼𝙋𝙋 𝘽𝙊𝙏', body: `ꨄ︎ ${conn.user.name}`, sourceUrl: '𝙀𝙉𝙑𝙄𝘼𝙉𝘿𝙊...', thumbnail: y}}})
 conn.sendFile(m.chat, dl_link, `𝙗𝙔 ${conn.user.name}.mp4`, `
 *${title}*
✅ ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏 ✅
`.trim(), m, false, {
  
ptt: false, duration: 999999999999, thumbnail: y , asDocument: chat.useDocument})
}
handler.command = /^yt(v|mp4)?$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0
handler.limit = false

module.exports = handler
