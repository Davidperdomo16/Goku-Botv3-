let fetch = require('node-fetch')
let handler = async (m, { conn, args, usedPrefix, command, text }) => {
response = args.join(' ').split('|')
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let mentionedJid = [who]
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤\n𝙚𝙟𝙚𝙢𝙥𝙡𝙤:)\n#𝙡𝙤𝙜𝙤𝙧𝙖𝙣𝙙𝙤𝙢 𝙖𝙣𝙮𝙖'        
let res = `https://api-alc.herokuapp.com/api/photooxy/${pickRandom(global.logos)}?texto=${response[0]}&apikey=ConfuMods`
conn.sendButtonImg(m.chat, res, "𝙡𝙤𝙜𝙤 𝙧𝙖𝙣𝙙𝙤𝙢 𝙩𝙚𝙧𝙢𝙞𝙣𝙖𝙙𝙤 𝙖𝙢𝙤𝙧❤️", 'ꨄ︎𝘼𝙉𝙔𝘼 𝙁𝙊𝙍𝙂𝙀𝙍 - 𝘽𝙊𝙏', '𝙨𝙞𝙜𝙪𝙞𝙚𝙣𝙩𝙚', `${usedPrefix + command} ${text}`, m, false, { contextInfo: { mentionedJid }})}
handler.command = /^(logorandom)$/i
module.exports = handler

function pickRandom(list) {
return list[Math.floor(list.length * Math.random())]}

global.logos = [
"text-on-scary", 
"coffee-cup",
"teks-cup",
"funny-cup",
"love-messages",
"romantic-messages",
"romantic-messages",
"flaming-fire",
"flaming-fire",
"romantic-double",
"burn-paper",
"text-on-scary", 
"under-grass",
"shadow-sky",
"love-messages",
"romantic-messages",
"coffee-cup",
"teks-cup",
"romantic-double"
] 
