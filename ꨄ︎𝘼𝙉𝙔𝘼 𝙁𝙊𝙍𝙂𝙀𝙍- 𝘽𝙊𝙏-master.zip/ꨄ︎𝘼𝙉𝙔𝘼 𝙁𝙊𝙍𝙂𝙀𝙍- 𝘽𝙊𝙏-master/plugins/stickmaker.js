const uploadImage = require('../lib/uploadImage')
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')
const effects = ['jail', 'gay', 'glass', 'wasted' ,'triggered', 'lolice', 'simpcard', 'horny']

let handler = async (m, { conn, usedPrefix, text }) => {
    let effect = text.trim().toLowerCase()
  if (!effects.includes(effect)) throw `
_✳️ 𝙐𝙎𝙊 𝘾𝙊𝙍𝙍𝙀𝘾𝙏𝙊 𝘿𝙀𝙇 𝘾𝙊𝙈𝘼𝙉𝘿𝙊 ✳️_

👉 𝙐𝙎𝙀: ${usedPrefix}stickermaker (efecto) 
- 𝙔 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼 𝙐𝙉𝘼 𝙄𝙈𝘼𝙂𝙀𝙉 

✅ 𝙀𝙅𝙀𝙈𝙋𝙇𝙊: ${usedPrefix}stickermaker jail

𝙇𝙄𝙎𝙏 𝙀𝙁𝙁𝙀𝘾𝙏:
${effects.map(effect => `_> ${effect}_`).join('\n')}
`.trim()
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) throw '⚠️𝙉𝙊 𝙎𝙀 𝙀𝙉𝘾𝙊𝙉𝙏𝙍𝙊 𝙇𝘼 𝙄𝙈𝘼𝙂𝙀𝙉\n\n✅ 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼 𝙐𝙉𝘼 𝙄𝙈𝘼𝙂𝙀𝙉'
  if (!/image\/(jpe?g|png)/.test(mime)) throw `⚠️ 𝙁𝙊𝙍𝙈𝘼𝙏𝙊 𝙉𝙊 𝘼𝘿𝙈𝙄𝙏𝙄𝘿𝙊\n\n👉🏻 𝙍𝙀𝙎𝙋𝙊𝙉𝘿𝘼 𝘼 𝙐𝙉𝘼 𝙄𝙈𝘼𝙂𝙀𝙉`
  let img = await q.download()
  let url = await uploadImage(img)
  let apiUrl = global.API('https://some-random-api.ml/canvas/', encodeURIComponent(effect), {
    avatar: url
  })
try {
    let stiker = await sticker(null, apiUrl, global.packname, global.author)
    await conn.sendMessage(m.chat, stiker, MessageType.sticker, {
      quoted: m
    })
  } catch (e) {
    m.reply('⚠️ 𝙊𝘾𝙐𝙍𝙍𝙄𝙊 𝙐𝙉 𝙀𝙍𝙍𝙊𝙍 𝙀𝙉 𝙇𝘼 𝘾𝙊𝙉𝙑𝙀𝙍𝙎𝙄𝙊𝙉 𝘿𝙀𝙇 𝙎𝙏𝙄𝘾𝙆𝙀𝙍\n\n✳️ 𝙀𝙉𝙑𝙄𝘼𝙉𝘿𝙊 𝙄𝙈𝘼𝙂𝙀𝙉 𝙀𝙉 𝙎𝙐 𝙇𝙐𝙂𝘼𝙍...')
    await conn.sendFile(m.chat, apiUrl, 'image.png', null, m)
  }
}

handler.help = ['stickmaker (caption|reply media)']
handler.tags = ['General']
handler.command = /^(stickmaker|stickermaker|stickermarker|cs)$/i
handler.limit = false
handler.group = false
handler.register = false
module.exports = handler
