let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/Alarma.mp3'
conn.sendFile(m.chat, vn, 'Alarma.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /alarma|Alarma|ALARMA/
handler.command = /^(ALARMA|alarma|Alarma?$)/

module.exports = handler
