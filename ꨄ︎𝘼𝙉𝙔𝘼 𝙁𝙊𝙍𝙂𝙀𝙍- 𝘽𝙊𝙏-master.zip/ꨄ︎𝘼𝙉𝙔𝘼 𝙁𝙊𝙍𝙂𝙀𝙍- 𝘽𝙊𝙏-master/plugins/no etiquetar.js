let handler = async (m, { conn, text }) => {
    let name = m.fromMe ? conn.user : conn.contacts[m.sender]

  conn.reply(m.chat, `
[ ⚠️ ️] 𝙉𝙤 𝙚𝙩𝙞𝙦𝙪𝙚𝙩𝙚𝙨 𝙖 𝙢𝙞 𝙘𝙧𝙚𝙖𝙙𝙤𝙧, 𝙨𝙞 𝙚𝙨 𝙖𝙡𝙜𝙤 𝙪𝙧𝙜𝙚𝙣𝙩𝙚 𝙘𝙤𝙣𝙩𝙖𝙘𝙩𝙖 𝙘𝙤𝙣 𝙚𝙡 𝙖 𝙨𝙪 𝙘𝙝𝙖𝙩 𝙥𝙧𝙞𝙫𝙖𝙙𝙤
`.trim(), m)
    let mentionedJid = [m.sender]
}
handler.customPrefix = /@50495086382|@50497501147/i
handler.command = new RegExp

module.exports = handler