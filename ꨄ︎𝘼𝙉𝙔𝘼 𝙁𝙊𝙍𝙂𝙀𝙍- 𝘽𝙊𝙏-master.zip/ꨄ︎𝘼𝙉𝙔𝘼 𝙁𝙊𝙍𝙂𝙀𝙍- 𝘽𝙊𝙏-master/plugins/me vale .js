let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/me vale.mp3'
conn.sendFile(m.chat, vn, 'me vale.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /me vale|ME VALE|Me vale/
handler.command = /^(me vale|ME VALE|Me vale?$)/

module.exports = handler