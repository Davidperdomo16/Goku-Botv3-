let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
response = args.join(' ').split('|')
if (!args[0]) throw '[⚠️] 𝙞𝙣𝙜𝙧𝙚𝙨𝙚 𝙪𝙣 𝙩𝙚𝙭𝙩𝙤\n𝙚𝙟𝙚𝙢𝙥𝙡𝙤:)\n*#𝙡𝙤𝙜𝙤𝙛𝙞𝙧𝙚 𝙖𝙣𝙮𝙖'        
let res = `https://api-alc.herokuapp.com/api/photooxy/burn-paper?texto=${response[0]}&apikey=ConfuMods`
conn.sendFile(m.chat, res, 'error.jpg', `*Logo terminado*`, m, false)}
handler.command = /^(logofire|fire)$/i
module.exports = handler
