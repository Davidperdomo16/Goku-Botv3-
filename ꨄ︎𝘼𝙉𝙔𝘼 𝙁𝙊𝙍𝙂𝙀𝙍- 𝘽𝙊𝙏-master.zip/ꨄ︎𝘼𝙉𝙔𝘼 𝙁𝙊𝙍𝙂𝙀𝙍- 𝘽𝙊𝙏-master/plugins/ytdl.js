process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const { servers, yta } = require('../lib/y2mate')
let handler = async (m, { conn, args, isPrems, isOwner }) => {
let chat = global.DATABASE.data.chats[m.chat]
  if (!args || !args[0]) throw '[⚠️] 𝙄𝙉𝙎𝙀𝙍𝙏𝘼𝙍 𝙐𝙉 𝙀𝙉𝙇𝘼𝘾𝙀 𝘿𝙀 𝙔𝙊𝙐𝙏𝙐𝘽𝙀\n\n𝙀𝙅𝙀𝙈𝙋𝙇𝙊:\n#𝙔𝙏mp3 https://www.youtube.com/watch?v=8jvDzEIVpjg*'
  let server = (args[1] || 'id4').toLowerCase()
  let { dl_link, thumb, title, filesize, filesizeF} = await yta(args[0], servers.includes(server) ? server : 'id4')
  //let isLimit = (isPrems || isOwner ? 99 : limit) * 1024 < filesize
 let fs = require('fs')
 let y = fs.readFileSync('./Menu2.jpg')


conn.sendMessage(m.chat, `⏯ ️𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝘿𝙊𝙍 𝘽𝙔 𝘼𝙉𝙔𝘼𝘽𝙊𝙏⏯️\n\n𝙏𝙄𝙏𝙐𝙇𝙊🔥 ${title}\n🗂️𝙏𝘼𝙈𝘼𝙉̃𝙊 𝘿𝙀𝙇 𝘼𝙍𝘾𝙃𝙄𝙑𝙊: ${filesizeF}` , '𝘾𝙊𝙉𝙑𝙀𝙍𝙎𝘼𝙏𝙄𝙊𝙉', {quoted: m, thumbnail: global.thumb, contextInfo:{externalAdReply: {title: '𝙎𝙄𝙈𝙋𝙇𝙀 𝙒𝙃𝘼𝙏𝙎𝘼𝙋𝙋 𝘽𝙊𝙏', body: `ꨄ︎ ${conn.user.name}`, sourceUrl: '𝙀𝙉𝙑𝙄𝘼𝙉𝘿𝙊...', thumbnail: y}}})
conn.sendFile(m.chat, dl_link , `𝘽𝙔 ${conn.user.name}.mp3`, m, false, {ptt: true, duration: 999999999999, asDocument: chat.useDocument})
conn.sendFile(m.chat, dl_link , `𝘽𝙔 ${conn.user.name}.mp3`, m)
}
handler.command = /^yt(a|mp3)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0

module.exports = handler
