let util = require('util')
let path = require('path')

let handler = async (m, { conn }) => {
let vn = './media/calla fan de bts.mp3'
conn.sendFile(m.chat, vn, 'calla fan de bts.mp3', null, m, true, {
type: 'audioMessage', // paksa tanpa convert di ffmpeg
ptt: true // true diatas ga work, sebab dipaksa tanpa convert ;v
})
}
handler.customPrefix = /bts|BTS|CALLA FAN DE BTS/calla fan de bts/
handler.command = /^(calla fan de bts|bts|BTS|CALLA FAN DE BTS?$)/

module.exports = handler