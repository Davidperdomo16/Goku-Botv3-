let handler = async (m, { conn, command, text }) => {
  conn.reply(m.chat, `
*⁉️ PREGUNTAS ⁉️*
  
*Pregunta:* ${text}
*Respuesta:* ${pickRandom(['𝙎𝙄','𝙏𝘼𝙇 𝙑𝙀𝙕 𝙎𝙄','𝙋𝙊𝙎𝙄𝘽𝙇𝙀𝙈𝙀𝙉𝙏𝙀','𝙋𝙍𝙊𝘽𝘼𝘽𝙇𝙀𝙈𝙀𝙉𝙏𝙀 𝙉𝙊','𝙉𝙊','𝙄𝙈𝙋𝙊𝙎𝙄𝘽𝙇𝙀'])}
`.trim(), m, m.mentionedJid ? {
    contextInfo: {
      mentionedJid: m.mentionedJid
    }
  } : {})
}
handler.help = ['apakah <teks>?']
handler.tags = ['kerang']
handler.command = /^apakah|pregunta/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

